import { SCHEMES } from "../data";
import { IMPORT_DATE } from "../data/financials";
import { COMBO_RULES } from "../data/sources";

/* ================================================================== */
/*  ENGINES (unchanged)                                                */
/* ================================================================== */
export const inr = (n) => {
  if (n == null) return "Not reported";
  if (n >= 10000000) return `₹${(n / 10000000).toLocaleString("en-IN", { maximumFractionDigits: 1 })} Cr`;
  if (n >= 100000) return `₹${(n / 100000).toLocaleString("en-IN", { maximumFractionDigits: 1 })} lakh`;
  return `₹${n.toLocaleString("en-IN")}`;
};
export const cr = (n) => (n == null ? "Not reported" : `₹${n.toLocaleString("en-IN")} Cr`);
export const NR = "Not reported";

export function matchScheme(s, p) {
  if (!s.criteria) return { evaluable: 0, matched: 0, manual: 0, pct: null, parts: [] };
  const parts = s.criteria.map((c) => {
    if (!c.check) return { text: c.text, state: "manual" };
    let ok = false;
    try { ok = !!c.check(p); } catch { ok = false; }
    return { text: c.text, state: ok ? "pass" : "fail" };
  });
  const evaluable = parts.filter((x) => x.state !== "manual").length;
  const matched = parts.filter((x) => x.state === "pass").length;
  const manual = parts.filter((x) => x.state === "manual").length;
  return { evaluable, matched, manual, pct: evaluable ? Math.round((matched / evaluable) * 100) : null, parts };
}
export function dataConfidence(s) {
  let pts = 0; const items = [];
  const add = (ok, w, label) => { if (ok) pts += w; items.push({ ok: !!ok, label, w }); };
  add(!!s.official_source_url, 20, "Official source URL on record");
  add(!!s.benefit_summary, 15, "Benefit verified from official source");
  add(!!s.criteria, 15, "Eligibility criteria verified");
  add(!!s.application_url, 15, "Official application URL verified");
  add(!!s.fin, 20, "Official budget financials attached");
  add(s.last_verified === IMPORT_DATE, 15, "Verified in latest import");
  const band = pts >= 80 ? "High confidence" : pts >= 55 ? "Moderate confidence" : "Limited data";
  return { pts, band, items };
}
export const reVsBe = (s) => {
  const y = s.fin?.years?.["2025-26"];
  return y && y.be != null && y.re != null ? Math.round((y.re / y.be) * 100) : null;
};
export const beOf = (s, fy) => s.fin?.years?.[fy]?.be ?? null;

export const SECTORS = [...new Set(SCHEMES.map((s) => s.sector))];
export const BLANK = { state: "", district: "", userType: "", incomeLabel: "", incomeMax: null, investment: "", loan: "", status: "", landholding: "", electricity: "", dpiit: "", incorpUnder2: "", foodProcessing: "" };
export const BEN_TYPES = ["Farmer", "MSME", "Startup", "Entrepreneur", "Student", "Self-employed", "Household", "SHG/FPO", "Other"];
export const INCOME_BANDS = [
  { label: "Below ₹2.5 lakh", max: 250000 }, { label: "₹2.5 – ₹8 lakh", max: 800000 },
  { label: "₹8 – ₹20 lakh", max: 2000000 }, { label: "Above ₹20 lakh", max: 99000000 },
];
export const STATES = ["Andhra Pradesh", "Bihar", "Gujarat", "Karnataka", "Madhya Pradesh", "Maharashtra", "Rajasthan", "Tamil Nadu", "Uttar Pradesh", "West Bengal", "Other state/UT"];
export const DEMO_PROFILE = {
  state: "Gujarat", district: "Ahmedabad", userType: "Entrepreneur", incomeLabel: "₹8 – ₹20 lakh", incomeMax: 2000000,
  investment: 2000000, loan: "Yes", status: "New project",
  landholding: "", electricity: "", dpiit: "", incorpUnder2: "", foodProcessing: "Yes",
};

export function combineVerdict(a, b) {
  if (!a || !b) return null;
  if (a.id === b.id) return { status: "invalid", rule: "Select two different schemes to run the check.", source: null, url: null };
  const hit = COMBO_RULES.find((r) => r.ids.includes(a.id) || r.ids.includes(b.id));
  if (hit) return hit;
  return {
    status: "unknown",
    rule: "Subsidy360 could not verify whether these schemes may be combined. No explicit official rule for this pairing is present in the imported dataset — check the official guidelines of both schemes before assuming compatibility.",
    source: null, url: null,
  };
}

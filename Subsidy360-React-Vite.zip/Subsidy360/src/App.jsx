import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  LayoutDashboard, Search, Compass, ListChecks, GitMerge, Landmark, Scale,
  BookOpen, Info, Menu, X, ChevronRight, ChevronLeft, CheckCircle2, AlertTriangle,
  XCircle, ArrowRight, ArrowDown, MapPin, Users, Wallet, TrendingUp, Layers, Sparkles,
  FileText, BadgeCheck, CircleDollarSign, PlayCircle, Filter, RotateCcw,
  ExternalLink, Database, ShieldCheck, CircleHelp, CalendarDays, Library,
  ScrollText, CircleSlash, FlaskConical, Bot, SlidersHorizontal, Radar, Grid3x3,
  Send,
} from "lucide-react";
import { SCHEMES, loadExternalSchemes } from "./data";
import { IMPORT_DATE, BUDGET_SRC } from "./data/financials";
import { SOURCES, COMBO_RULES, RADAR } from "./data/sources";
import { Logo } from "./components/shared";
import { Dashboard, FindSubsidy, Copilot, WhatIf } from "./pages/discover";
import { AllSchemes, SchemeDetail, ComboChecker, PublicMoney, Impact, CompareSchemes } from "./pages/analyse";
import { PolicyRadar, DataSources, Methodology, About } from "./pages/verify";

/* ================================================================== */
/*  APP SHELL — grouped premium sidebar + footer                       */
/* ================================================================== */
const NAV_GROUPS = [
  { title: null, items: [{ id: "dashboard", label: "Dashboard", icon: LayoutDashboard }] },
  { title: "Discover", items: [
    { id: "find", label: "Find My Subsidy", icon: Compass },
    { id: "schemes", label: "All Schemes", icon: ListChecks },
    { id: "copilot", label: "Subsidy Copilot", icon: Bot },
  ]},
  { title: "Analyse", items: [
    { id: "money", label: "Public Money", icon: Landmark },
    { id: "whatif", label: "What-If", icon: SlidersHorizontal },
    { id: "impact", label: "Economic Impact", icon: TrendingUp },
    { id: "compare", label: "Compare", icon: Scale },
    { id: "combo", label: "Subsidy Combination", icon: GitMerge },
  ]},
  { title: "Verify", items: [
    { id: "radar", label: "Policy Radar", icon: Radar },
    { id: "sources", label: "Data Sources", icon: Database },
    { id: "method", label: "Data Methodology", icon: FlaskConical },
  ]},
  { title: "Project", items: [{ id: "about", label: "About Subsidy360", icon: Info }] },
];

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [schemeId, setSchemeId] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profile, setProfile] = useState(null);
  const [results, setResults] = useState(null);
  const [, setExternalAdded] = useState(0);
  useEffect(() => { document.title = "Subsidy360 · Economics Project"; }, []);
  useEffect(() => { loadExternalSchemes().then((n) => { if (n > 0) setExternalAdded(n); }); }, []);
  const go = (p) => { setPage(p); setSchemeId(null); setMenuOpen(false); window.scrollTo({ top: 0 }); };
  const openScheme = (id) => { setSchemeId(id); setPage("detail"); window.scrollTo({ top: 0 }); };
  const scheme = SCHEMES.find((s) => s.id === schemeId);

  const content =
    page === "detail" && scheme ? <SchemeDetail s={scheme} profile={profile} back={() => setPage(results ? "find" : "schemes")} go={go} /> :
    page === "find" ? <FindSubsidy profile={profile} setProfile={setProfile} results={results} setResults={setResults} openScheme={openScheme} go={go} /> :
    page === "schemes" ? <AllSchemes openScheme={openScheme} /> :
    page === "copilot" ? <Copilot openScheme={openScheme} /> :
    page === "money" ? <PublicMoney openScheme={openScheme} /> :
    page === "whatif" ? <WhatIf openScheme={openScheme} /> :
    page === "impact" ? <Impact /> :
    page === "compare" ? <CompareSchemes profile={profile} openScheme={openScheme} /> :
    page === "combo" ? <ComboChecker /> :
    page === "radar" ? <PolicyRadar /> :
    page === "sources" ? <DataSources /> :
    page === "method" ? <Methodology /> :
    page === "about" ? <About /> :
    <Dashboard go={go} openScheme={openScheme} />;

  const NavLinks = () => (
    <nav className="space-y-4">
      {NAV_GROUPS.map((g, gi) => (
        <div key={gi}>
          {g.title && <div className="f-mono t9 uppercase tracking-widest tx-dim2 px-3.5 mb-1.5">{g.title}</div>}
          <div className="space-y-0.5">
            {g.items.map((n) => {
              const active = page === n.id || (page === "detail" && n.id === "schemes" && !results) || (page === "detail" && n.id === "find" && results);
              return (
                <button key={n.id} onClick={() => go(n.id)}
                  className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-2 text-sm font-medium transition-colors focus:outline-none ${active ? "tx-em" : "tx-dim hover:tx-bright"}`}
                  style={active ? { background: "rgba(24,185,129,.1)", border: "1px solid rgba(24,185,129,.35)" } : { border: "1px solid transparent" }}>
                  <n.icon className={`w-4 h-4 ${active ? "tx-em" : "tx-dim2"}`} />
                  {n.label}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );

  return (
    <div className="s360-root min-h-screen bg-navy">
      <div className="s360-wm" aria-hidden="true">SUBSIDY360 • ECONOMICS PROJECT</div>
      {/* Mobile top bar */}
      <div className="lg:hidden sticky top-0 z-40 bg-navy2 border-b bd-line px-4 py-3 flex items-center justify-between">
        <button onClick={() => go("dashboard")} className="focus:outline-none"><Logo /></button>
        <button onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu" className="p-2 rounded-xl border bd-line tx-dim focus:outline-none">
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>
      {menuOpen && (
        <div className="lg:hidden fixed inset-0 z-30" style={{ background: "rgba(4,12,20,.7)" }} onClick={() => setMenuOpen(false)}>
          <div className="bg-navy2 w-72 h-full pt-20 px-4 pb-6 overflow-y-auto scroll-thin border-r bd-line" onClick={(e) => e.stopPropagation()}><NavLinks /></div>
        </div>
      )}
      <div className="lg:flex">
        <aside className="hidden lg:flex flex-col w-72 shrink-0 h-screen sticky top-0 border-r bd-line bg-navy2 px-4 py-6 overflow-y-auto scroll-thin">
          <button onClick={() => go("dashboard")} className="mb-7 px-2 text-left focus:outline-none"><Logo /></button>
          <NavLinks />
          <div className="mt-auto pt-6 space-y-2">
            <div className="f-mono t9 uppercase tracking-widest tx-dim2">Subsidy360 • Economics Project</div>
            <div className="t10 tx-dim2 leading-relaxed f-mono">Official source data — imported {IMPORT_DATE}</div>
          </div>
        </aside>
        <main className="flex-1 min-w-0 px-4 sm:px-6 lg:px-10 py-6 lg:py-10 max-w-6xl mx-auto w-full">
          {content}
          <footer className="mt-14 pt-8 border-t bd-line">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
              <div>
                <div className="f-display font-bold tx-bright text-lg">SUBSIDY<span className="tx-em">360</span></div>
                <div className="f-mono t10 uppercase tracking-widest tx-dim2 mt-1">Discover. Qualify. Compare. Understand.</div>
              </div>
              <div className="flex flex-wrap gap-x-6 gap-y-2 t11">
                {[["Official Sources", "sources"], ["Data Methodology", "method"], ["Policy Radar", "radar"], ["About Project", "about"]].map(([l, id]) => (
                  <button key={id} onClick={() => go(id)} className="tx-dim hover:tx-bright font-medium focus:outline-none">{l}</button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between flex-wrap gap-2 mt-6 pb-2">
              <span className="f-mono t10 tx-dim2">SUBSIDY360 • ECONOMICS PROJECT</span>
              <span className="t10 tx-dim2">Academic prototype · missing data shown as "Not reported", never estimated</span>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}

import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  LayoutDashboard, Search, Compass, ListChecks, GitMerge, Landmark, Scale,
  BookOpen, Info, Menu, X, ChevronRight, ChevronLeft, CheckCircle2, AlertTriangle,
  XCircle, ArrowRight, ArrowDown, MapPin, Users, Wallet, TrendingUp, Layers, Sparkles,
  FileText, BadgeCheck, CircleDollarSign, PlayCircle, Filter, RotateCcw,
  ExternalLink, Database, ShieldCheck, CircleHelp, CalendarDays, Library,
  ScrollText, CircleSlash, FlaskConical, Bot, SlidersHorizontal, Radar, Grid3x3,
  Send,
} from "lucide-react";
import { IMPORT_DATE, BUDGET_SRC } from "../data/financials";
import { inr, cr, NR, dataConfidence, reVsBe, beOf } from "../engine";

/* ================================================================== */
/*  SHARED PREMIUM UI                                                  */
/* ================================================================== */
export const Logo = ({ small }) => (
  <div className="flex items-center gap-2.5">
    <div className="relative w-9 h-9 rounded-xl flex items-center justify-center shadow-sm" style={{ background: "linear-gradient(135deg,#18B981,#177E8E)" }}>
      <Landmark className="w-5 h-5 text-white" />
      <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2" style={{ background: "var(--gd)", borderColor: "var(--navy)" }} />
    </div>
    {!small && (
      <div className="leading-tight">
        <div className="f-display text-lg font-bold tx-bright">Subsidy<span className="tx-em">360</span></div>
        <div className="f-mono t9 tracking-widest uppercase tx-dim2">Discover · Qualify · Compare · Understand</div>
      </div>
    )}
  </div>
);
export const Eyebrow = ({ children, dark }) => (
  <div className={`f-mono t11 uppercase tracking-widest mb-2 ${dark ? "tx-cy" : "tx-cyd"}`}>{children}</div>
);
export const Chip = ({ kind, children }) => <span className={`chip ${kind}`}>{children}</span>;
export const StatusChip = ({ s, dark }) =>
  s === "verified" ? <Chip kind={dark ? "chip-ver-d" : "chip-ver"}>Verified</Chip>
    : s === "financials-verified" ? <Chip kind={dark ? "chip-src-d" : "chip-src"}>Official source</Chip>
    : s === "pending" ? <Chip kind="chip-warn">Needs verification</Chip>
    : <Chip kind={dark ? "chip-nr-d" : "chip-nr"}>Not reported</Chip>;

/* ⓘ Source — tap-to-reveal indicator for financial numbers */
export function SourceInfo({ name, url, dark }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-block">
      <button onClick={() => setOpen(!open)} aria-label="Show source"
        className={`f-mono t10 inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 border transition-colors focus:outline-none ${dark ? "tx-dim bd-line hover:tx-cy" : "tx-ink3 bd-soft hover:tx-cyd"}`}>
        <Info className="w-3 h-3" /> Source
      </button>
      {open && (
        <span className={`absolute z-30 left-0 top-full mt-1.5 w-60 rounded-xl border p-3 t11 shadow-xl block ${dark ? "bg-navy3 bd-line tx-dim" : "bg-card bd-soft tx-ink2"}`}>
          <span className={`block font-medium mb-1 ${dark ? "tx-bright" : "tx-ink"}`}>{name}</span>
          <a href={url} target="_blank" rel="noopener noreferrer" className={`inline-flex items-center gap-1 font-medium ${dark ? "tx-cy" : "tx-cyd"}`}>
            Open official source <ExternalLink className="w-3 h-3" />
          </a>
        </span>
      )}
    </span>
  );
}
export const Field = ({ v }) => (v == null || v === "" ? <span className="italic tx-ink3">{NR}</span> : <>{v}</>);
export const NRRow = () => <Chip kind="chip-nr">{NR}</Chip>;

export const ChartTip = ({ active, payload, label, unit = " Cr", prefix = "₹" }) => {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-lg shadow-xl px-3 py-2 text-xs border" style={{ background: "var(--navy3)", borderColor: "var(--line)", color: "var(--bright)" }}>
      <div className="font-semibold mb-1">{label}</div>
      {payload.map((p) => (
        <div key={p.name} className="flex items-center gap-2" style={{ color: "var(--dim)" }}>
          <span className="w-2 h-2 rounded-full" style={{ background: p.color || p.fill }} />
          {p.name}: <span className="f-mono font-medium" style={{ color: "var(--bright)" }}>{prefix}{Number(p.value).toLocaleString("en-IN")}{unit}</span>
        </div>
      ))}
    </div>
  );
};
export const CH = { alloc: "#22B8CF", util: "#18B981", bench: "#E7B75B", warn: "#F2B84B", down: "#E06B6B", deep: "#177E8E" };
export const AXIS_D = { fontSize: 10, fill: "#8FA6B8" };
export const GRID_D = "#1C3A52";

export const Disclaimer = ({ dark }) => (
  <p className={`text-xs leading-relaxed rounded-xl p-4 border ${dark ? "tx-dim bg-navy2 bd-line" : "tx-ink3 bg-card bd-soft"}`}>
    <strong className={dark ? "tx-bright" : "tx-ink2"}>Disclaimer:</strong> Subsidy360 is an academic prototype for
    educational and demonstration purposes. Scheme information and financial figures are imported from the official
    sources cited on each record; anything unconfirmed is shown as "Not reported" rather than estimated. This is not
    official government advice — verify with the relevant department or official portal before applying.
  </p>
);
export const ImportBadge = ({ dark }) => (
  <span className={`inline-flex items-center gap-1.5 chip ${dark ? "chip-src-d" : "chip-src"}`}>
    <Database className="w-3 h-3" /> Official source data — last imported {IMPORT_DATE}
  </span>
);
export const MatchDisclaimer = ({ dark }) => (
  <p className={`t11 rounded-lg px-3 py-2 border ${dark ? "bg-navy3 bd-line tx-dim" : ""}`} style={dark ? {} : { background: "rgba(242,184,75,.1)", borderColor: "rgba(242,184,75,.45)", color: "#7A5510" }}>
    Subsidy360 Match is an informational ranking of fit against machine-checkable official criteria. It is not an
    official eligibility decision — that always rests on the official scheme rules linked from each record.
  </p>
);

/* Scheme card — light analytical card */
export function SchemeCard({ s, match, onOpen, benefitNote }) {
  return (
    <div className="card-l lift p-5 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="f-mono t10 uppercase tracking-wider tx-ink3">{s.level} · {s.sector}</div>
          <h3 className="font-semibold tx-ink leading-snug">{s.name}</h3>
          <div className="t11 tx-ink3 mt-0.5">{s.ministry}</div>
        </div>
        {match && match.pct != null && (
          <div className="text-right shrink-0">
            <div className="f-mono text-2xl font-bold tx-emd">{match.pct}%</div>
            <div className="t9 f-mono tx-ink3 uppercase">Subsidy360 Match</div>
          </div>
        )}
      </div>
      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-sm">
        <div className="tx-ink3">Benefit</div>
        <div className="text-right font-medium tx-ink t11 leading-snug"><Field v={s.benefit_summary ? (s.subsidy_pct || inr(s.max_benefit)) : null} /></div>
        <div className="tx-ink3">BE 2026-27</div>
        <div className="f-mono text-right tx-ink">{beOf(s, "2026-27") != null ? cr(beOf(s, "2026-27")) : <span className="italic tx-ink3">{NR}</span>}</div>
        <div className="tx-ink3">RE vs BE 2025-26</div>
        <div className="f-mono text-right tx-ink">{reVsBe(s) != null ? `${reVsBe(s)}%` : <span className="italic tx-ink3">{NR}</span>}</div>
      </div>
      {benefitNote && <div className="t11 tx-emd font-medium bg-paper rounded-lg px-2.5 py-1.5 border bd-soft">{benefitNote}</div>}
      <div className="flex items-center gap-2 flex-wrap">
        <StatusChip s={s.data_status} />
        <Chip kind={dataConfidence(s).pts >= 80 ? "chip-ver" : dataConfidence(s).pts >= 55 ? "chip-src" : "chip-warn"}>Data {dataConfidence(s).pts}/100</Chip>
      </div>
      {match && (
        <div className="t11 tx-ink2 bg-paper rounded-lg px-2.5 py-1.5 border bd-soft">
          Official criteria matched: <strong className="f-mono tx-ink">{match.matched}/{match.evaluable}</strong> evaluable
          {match.manual > 0 && <> · {match.manual} manual</>}
        </div>
      )}
      <button onClick={onOpen} className="mt-auto inline-flex items-center justify-center gap-1.5 border bd-soft hover:border-emerald-500 hover:tx-emd rounded-xl px-4 py-2 text-sm font-medium tx-ink2 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-300">
        View record <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}


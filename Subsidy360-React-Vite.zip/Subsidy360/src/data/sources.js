import { BUDGET_SRC } from "./financials";


export const SOURCES = [
  { name: "myScheme (national scheme-discovery platform)", url: "https://www.myscheme.gov.in/", role: "Primary scheme-discovery layer (Level 4). Central + State/UT scheme information, eligibility and application links.", level: 4 },
  { name: "Open Government Data Platform India", url: "https://data.gov.in/", role: "Official datasets/APIs for expenditure, beneficiaries and scheme performance (Level 2). Connection point for live ingestion.", level: 2 },
  { name: "Union Budget / indiabudget.gov.in", url: "https://www.indiabudget.gov.in/", role: "Expenditure Budget: scheme-wise Actuals, BE and RE (Level 3 documents). Source of every financial figure in this import.", level: 3 },
  { name: "PM-KISAN portal", url: "https://pmkisan.gov.in/", role: "Official scheme portal — benefit and application (Level 3).", level: 3 },
  { name: "PM Surya Ghar national portal", url: "https://pmsuryaghar.gov.in/", role: "Official scheme portal — subsidy slabs and application (Level 3).", level: 3 },
  { name: "PMEGP e-portal & Guidelines 2022 (KVIC)", url: "https://www.kviconline.gov.in/pmegpeportal/", role: "Official guidelines PDF — subsidy rates, caps and the other-subsidy prohibition (Level 3).", level: 3 },
  { name: "PMFME portal (MoFPI)", url: "https://pmfme.mofpi.gov.in/", role: "Official scheme portal — 35% credit-linked subsidy details (Level 3).", level: 3 },
  { name: "Startup India Seed Fund portal (DPIIT)", url: "https://seedfund.startupindia.gov.in/", role: "Official scheme portal — grant/debt structure and startup criteria (Level 3).", level: 3 },
  { name: "PRS Legislative Research — Union Budget 2026-27 Analysis", url: "https://prsindia.org/files/budget/budget_parliament/2026/Union_Budget_Analysis-2026-27.pdf", role: "Secondary compilation used only to cross-check budget-document figures (Level 5 — not authoritative on its own).", level: 5 },
];

export const COMBO_RULES = [
  {
    ids: ["PMEGP", "*"], status: "prohibited",
    rule: "PMEGP Guidelines: units that have already availed subsidy under any other Central or State Government scheme are not eligible for PMEGP margin-money subsidy (and vice-versa for the same unit/project).",
    source: "PMEGP Guidelines (certified, 2022), KVIC / Ministry of MSME",
    url: "https://www.kviconline.gov.in/pmegpeportal/dashboard/notification/PMEGP_Guidelines_Certified_2022_3.pdf",
    verified: "24/08/2026",
  },
  {
    ids: ["SISFS", "*"], status: "conditional",
    rule: "SISFS eligibility requires that the startup has not received more than ₹10 lakh of monetary support under any other Central/State Government scheme. Combination is therefore possible only within that ceiling — verify the specific pairing.",
    source: "Startup India Seed Fund Scheme guidelines, DPIIT",
    url: "https://seedfund.startupindia.gov.in/",
    verified: "24/08/2026",
  },
];

/* Policy Radar — verified changes, all sourced to Union Budget 2026-27 */
export const RADAR = [
  { tag: "NEW", scheme: "VB-G RAM G (Gramin)", text: "New rural employment & livelihoods mission introduced with a ₹95,692 Cr Budget Estimate for 2026-27.", dept: "Ministry of Rural Development", date: "Feb 2026", src: BUDGET_SRC.url, srcName: "Union Budget 2026-27" },
  { tag: "FUNDING", scheme: "MGNREGS", text: "BE 2026-27 set at ₹30,000 Cr against ₹88,000 Cr RE 2025-26 — a major re-prioritisation alongside the new VB-G RAM G mission.", dept: "Ministry of Rural Development", date: "Feb 2026", src: BUDGET_SRC.url, srcName: "Union Budget 2026-27" },
  { tag: "FUNDING", scheme: "PM Surya Ghar", text: "BE raised to ₹22,000 Cr for 2026-27 (from ₹17,000 Cr RE 2025-26), continuing the rooftop-solar push.", dept: "MNRE", date: "Feb 2026", src: BUDGET_SRC.url, srcName: "Union Budget 2026-27" },
  { tag: "FUNDING", scheme: "Jal Jeevan Mission", text: "RE 2025-26 revised sharply to ₹17,000 Cr from a ₹67,000 Cr BE; BE 2026-27 restored to ₹67,670 Cr.", dept: "Ministry of Jal Shakti", date: "Feb 2026", src: BUDGET_SRC.url, srcName: "Union Budget 2026-27" },
  { tag: "FUNDING", scheme: "PM-KUSUM", text: "BE 2026-27 nearly doubled to ₹5,000 Cr from ₹2,600 Cr RE 2025-26 for farm solarisation.", dept: "MNRE", date: "Feb 2026", src: BUDGET_SRC.url, srcName: "Union Budget 2026-27" },
];

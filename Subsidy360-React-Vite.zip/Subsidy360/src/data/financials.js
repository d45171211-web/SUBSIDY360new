
/* ================================================================== */
/*  DATA LAYER — unchanged honesty rules                               */
/*  · Every record cites an official source + last_verified date.      */
/*  · Unconfirmed fields are null → rendered "Not reported".           */
/*  · Financials are labelled BE / RE / Actuals, never mixed, never    */
/*    converted into invented sanction/release/utilisation stages.     */
/*  · No live API in this artifact: runs on a verified research        */
/*    import dated 24/08/2026 ("prototype synchronization").           */
/* ================================================================== */
export const IMPORT_DATE = "24/08/2026";
export const BUDGET_SRC = {
  name: "Union Budget documents (Expenditure Budget), Government of India",
  url: "https://www.indiabudget.gov.in/",
  compiled: "https://prsindia.org/files/budget/budget_parliament/2026/Union_Budget_Analysis-2026-27.pdf",
};


/*  Financial series live separately from scheme records. Values are ₹ crore.
    Supported per-FY keys: actual · be · re · sanctioned · released · utilised · beneficiaries.
    A key is present ONLY when an official source reports it; the UI renders
    absent keys as "Not reported". BE ≠ sanctioned ≠ released ≠ utilised — never inferred. */
export const FINANCIALS = {
  PMKISAN: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 66121 }, "2025-26": { be: 63500, re: 63500 }, "2026-27": { be: 63500 } } },
  PMSG: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2025-26": { be: 20000, re: 17000 }, "2026-27": { be: 22000 } } },
  PMFME: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2025-26": { be: 2000, re: 1500 } } },
  PMAYG: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 32327 }, "2025-26": { be: 54832, re: 32500 }, "2026-27": { be: 54917 } } },
  PMAYU: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 5865 }, "2025-26": { be: 25794, re: 7900 }, "2026-27": { be: 22025 } } },
  PMFBY: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2026-27": { be: 12200 } } },
  MISS: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 22600 }, "2025-26": { be: 22600, re: 22600 }, "2026-27": { be: 22600 } } },
  KUSUM: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2025-26": { re: 2600 }, "2026-27": { be: 5000 } } },
  MGNREGS: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 85834 }, "2025-26": { be: 86000, re: 88000 }, "2026-27": { be: 30000 } } },
  VBGRAMG: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2026-27": { be: 95692 } } },
  JJM: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 22612 }, "2025-26": { be: 67000, re: 17000 }, "2026-27": { be: 67670 } } },
  SAMAGRA: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 36288 }, "2025-26": { be: 41250, re: 38000 }, "2026-27": { be: 42100 } } },
  NHM: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 38889 }, "2025-26": { be: 37227, re: 37100 }, "2026-27": { be: 39390 } } },
  POSHAN: { srcName: BUDGET_SRC.name, srcUrl: BUDGET_SRC.url, years: { "2024-25": { actual: 21014 }, "2025-26": { be: 21960, re: 20949 }, "2026-27": { be: 23100 } } },
};

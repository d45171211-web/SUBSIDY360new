/* ==================================================================
   DATA LAYER — ingestion, normalisation, validation, search indexing
   Official sources → import → normalise/validate → SCHEMES registry
   → engines → UI. The UI never hard-codes a scheme count: it reads
   SCHEMES.length, so the figures on screen always reflect records
   actually loaded. External datasets (e.g. a myScheme / data.gov.in
   export dropped at public/data/external-schemes.json) are merged at
   runtime after passing the same validation — never invented.
   ================================================================== */
import { SEED_SCHEMES } from "./seedSchemes";

const REQUIRED = ["id", "name", "ministry", "level", "sector", "official_source_url", "source_org", "source_type", "last_verified", "data_status"];

export function validateRecord(r) {
  if (!r || typeof r !== "object") return false;
  for (const k of REQUIRED) if (r[k] == null || r[k] === "") return false;
  if (!Array.isArray(r.beneficiary) || r.beneficiary.length === 0) return false;
  return true;
}

function normalise(r) {
  const n = {
    state: "All India", beneficiary: [], objective: null, benefit_summary: null,
    max_benefit: null, subsidy_pct: null, benefit_type: null, loan_linked: false,
    application_url: null, documents: null, criteria: null, fin: null, scheme_outlay: null,
    ...r,
  };
  n._search = [n.name, n.ministry, n.dept, n.sector, n.state, n.benefit_summary, (n.beneficiary || []).join(" ")]
    .filter(Boolean).join(" ").toLowerCase();
  return n;
}

/* Live registry — seed first; validated external records are appended. */
export const SCHEMES = SEED_SCHEMES.filter(validateRecord).map(normalise);
export const schemeCount = () => SCHEMES.length;
export const findScheme = (id) => SCHEMES.find((s) => s.id === id);

/* Runtime ingestion of an external dataset (optional).
   Format: { "schemes": [ ...records... ], "financials": { "<ID>": { srcName, srcUrl, years: {...} } } }
   Invalid records are skipped and counted — never silently "fixed". */
export async function loadExternalSchemes(url = "/data/external-schemes.json") {
  try {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) return 0;
    const json = await res.json();
    const recs = Array.isArray(json?.schemes) ? json.schemes : [];
    const fins = json?.financials || {};
    let added = 0;
    for (const r of recs) {
      if (!validateRecord(r)) continue;
      if (SCHEMES.some((s) => s.id === r.id)) continue;
      if (fins[r.id]) r.fin = fins[r.id];
      SCHEMES.push(normalise(r));
      added++;
    }
    return added;
  } catch {
    return 0; /* no external dataset connected — seed import continues to serve */
  }
}

import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  Legend, PieChart, Pie, Cell,
} from "recharts";
import {
  LayoutDashboard, Search, Compass, ListChecks, GitMerge, Landmark, Scale,
  BookOpen, Info, Menu, X, ChevronRight, ChevronLeft, CheckCircle2, AlertTriangle,
  XCircle, ArrowRight, ArrowDown, MapPin, Users, Wallet, TrendingUp, Layers, Sparkles,
  FileText, BadgeCheck, CircleDollarSign, PlayCircle, Filter, RotateCcw,
  ExternalLink, Database, ShieldCheck, CircleHelp, CalendarDays, Library,
  ScrollText, CircleSlash, FlaskConical, Bot, SlidersHorizontal, Radar, Grid3x3,
  Send,
} from "lucide-react";
import { SCHEMES, loadExternalSchemes } from "../data";
import { IMPORT_DATE, BUDGET_SRC } from "../data/financials";
import { SOURCES, COMBO_RULES, RADAR } from "../data/sources";
import { inr, cr, NR, matchScheme, dataConfidence, reVsBe, beOf, combineVerdict,
  SECTORS, BEN_TYPES, INCOME_BANDS, STATES, DEMO_PROFILE, BLANK } from "../engine";
import { Logo, Eyebrow, Chip, StatusChip, SourceInfo, Field, NRRow, ChartTip,
  CH, AXIS_D, GRID_D, Disclaimer, ImportBadge, MatchDisclaimer, SchemeCard } from "../components/shared";
import { useCountUp } from "../hooks";

/* ================================================================== */
/*  ALL SCHEMES                                                        */
/* ================================================================== */
export function AllSchemes({ openScheme }) {
  const [q, setQ] = useState("");
  const [fSector, setFSector] = useState("All");
  const [fBen, setFBen] = useState("All");
  const [fMin, setFMin] = useState("All");
  const [fData, setFData] = useState("All");
  const [pageN, setPageN] = useState(0);
  useEffect(() => { setPageN(0); }, [q, fSector, fBen, fMin, fData]);
  const ministries = [...new Set(SCHEMES.map((s) => s.ministry))];
  const filtered = useMemo(() => SCHEMES.filter((s) => {
    const text = `${s.name} ${s.ministry} ${s.dept} ${s.sector} ${s.benefit_summary || ""}`.toLowerCase();
    if (q && !text.includes(q.toLowerCase())) return false;
    if (fSector !== "All" && s.sector !== fSector) return false;
    if (fBen !== "All" && !s.beneficiary.includes(fBen)) return false;
    if (fMin !== "All" && s.ministry !== fMin) return false;
    if (fData === "Fully verified" && s.data_status !== "verified") return false;
    if (fData === "Financials only" && s.data_status !== "financials-verified") return false;
    return true;
  }), [q, fSector, fBen, fMin, fData]);
  const PER_PAGE = 24;
  const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const visible = filtered.slice(pageN * PER_PAGE, (pageN + 1) * PER_PAGE);
  const selCls = "rounded-xl border bd-line px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 max-w-full tx-bright";
  const Sel = ({ value, onChange, options, label }) => (
    <label className="text-xs tx-dim2 min-w-0">
      <span className="block mb-1 f-mono uppercase tracking-wide">{label}</span>
      <select className={selCls} style={{ background: "var(--navy3)" }} value={value} onChange={(e) => onChange(e.target.value)}>
        <option>All</option>{options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </label>
  );
  return (
    <div className="fade-in space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <Eyebrow dark>Scheme database</Eyebrow>
          <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">All Government Schemes</h1>
          <p className="text-sm tx-dim mt-1">Every record cites its official source. The format scales to thousands of schemes via the myScheme / data.gov.in ingestion layer.</p>
          <p className="t11 tx-dim2 mt-1 f-mono">Built to scale to the full myScheme catalogue (4,700+ Central & State/UT schemes, as reported by myScheme) — the count shown is records actually loaded, never a hard-coded figure.</p>
        </div>
        <ImportBadge dark />
      </div>
      <div className="card-d p-4 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 tx-dim2 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search schemes — e.g., solar subsidy, seed fund, crop insurance…"
            className="w-full rounded-xl border bd-line pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 tx-bright" style={{ background: "var(--navy3)" }} />
        </div>
        <div className="flex flex-wrap gap-3 items-end">
          <Filter className="w-4 h-4 tx-dim2 mb-2.5" />
          <Sel label="Sector" value={fSector} onChange={setFSector} options={SECTORS} />
          <Sel label="Beneficiary" value={fBen} onChange={setFBen} options={BEN_TYPES.filter((b) => b !== "Other")} />
          <Sel label="Ministry" value={fMin} onChange={setFMin} options={ministries} />
          <Sel label="Data status" value={fData} onChange={setFData} options={["Fully verified", "Financials only"]} />
        </div>
      </div>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="text-sm tx-dim f-mono">{filtered.length} of {SCHEMES.length} loaded records · page {pageN + 1}/{pages}</div>
        <div className="flex gap-2">
          <button disabled={pageN === 0} onClick={() => setPageN(pageN - 1)} className="btn-ghost-d t11 rounded-lg px-3 py-1.5 disabled:opacity-40 focus:outline-none">← Prev</button>
          <button disabled={pageN >= pages - 1} onClick={() => setPageN(pageN + 1)} className="btn-ghost-d t11 rounded-lg px-3 py-1.5 disabled:opacity-40 focus:outline-none">Next →</button>
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {visible.map((s) => <SchemeCard key={s.id} s={s} onOpen={() => openScheme(s.id)} />)}
        {filtered.length === 0 && <div className="card-d p-8 text-center text-sm tx-dim md:col-span-2">No imported schemes match these filters. Broaden the search — or check myScheme for schemes not yet imported.</div>}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  SCHEME DETAIL — split layout with prominent match panel            */
/* ================================================================== */
export function SchemeDetail({ s, profile, back, go }) {
  const m = profile && s.criteria ? matchScheme(s, profile) : null;
  const conf = dataConfidence(s);
  const comboRule = COMBO_RULES.find((r) => r.ids.includes(s.id));
  const availability = [
    ["Eligibility", !!s.criteria], ["Benefits", !!s.benefit_summary], ["Application URL", !!s.application_url],
    ["Budget financials", !!s.fin], ["Documents", !!s.documents],
  ];
  return (
    <div className="fade-in space-y-6">
      <button onClick={back} className="inline-flex items-center gap-1 text-sm font-medium tx-dim hover:tx-bright focus:outline-none"><ChevronLeft className="w-4 h-4" /> Back</button>
      <div>
        <Eyebrow dark>{s.level} scheme · {s.sector}</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">{s.name}</h1>
        <p className="text-sm tx-dim mt-1">{s.ministry} · {s.dept}</p>
        <div className="mt-2 flex items-center gap-2 flex-wrap"><StatusChip s={s.data_status} dark /><Chip kind={conf.pts >= 80 ? "chip-ver-d" : "chip-src-d"}>Data {conf.pts}/100 · {conf.band}</Chip></div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4 items-start">
        {/* LEFT: scheme information */}
        <div className="lg:col-span-2 space-y-4">
          <div className="card-l p-6 space-y-3">
            <h3 className="font-semibold tx-ink flex items-center gap-2"><FileText className="w-4 h-4 tx-cyd" /> Overview</h3>
            {[["Government", s.level === "Central" ? "Government of India" : s.state], ["Ministry", s.ministry], ["Department / agency", s.dept],
              ["Who can apply", s.beneficiary.join(", ")], ["Benefit type", s.benefit_type]].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 text-sm border-b bd-soft pb-2 last:border-0">
                <span className="tx-ink3 shrink-0">{k}</span><span className="font-medium tx-ink text-right"><Field v={v} /></span>
              </div>
            ))}
            <p className="text-sm tx-ink2 leading-relaxed pt-1">{s.objective}</p>
          </div>
          <div className="card-l p-6 space-y-3">
            <h3 className="font-semibold tx-ink flex items-center gap-2"><CircleDollarSign className="w-4 h-4 tx-cyd" /> Benefits & financial assistance</h3>
            <p className="text-sm tx-ink leading-relaxed font-medium"><Field v={s.benefit_summary} /></p>
            {[["Subsidy percentage", s.subsidy_pct], ["Maximum benefit", s.max_benefit != null ? inr(s.max_benefit) : null],
              ["Bank-loan linked", s.benefit_summary ? (s.loan_linked ? "Yes" : "No") : null],
              ["Application deadline", null], ["Total scheme outlay", s.scheme_outlay != null ? cr(s.scheme_outlay) : null]].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 text-sm border-b bd-soft pb-2 last:border-0">
                <span className="tx-ink3">{k}</span><span className="f-mono font-medium tx-ink text-right"><Field v={v} /></span>
              </div>
            ))}
          </div>
          <div className="card-l p-6">
            <h3 className="font-semibold tx-ink mb-3 flex items-center gap-2"><Landmark className="w-4 h-4 tx-cyd" /> Union Budget financials (₹ Cr) {s.fin && <SourceInfo name={s.fin.srcName} url={s.fin.srcUrl} />}</h3>
            {s.fin ? (
              <>
                <table className="w-full text-sm">
                  <thead><tr className="text-left f-mono t10 uppercase tracking-wider tx-ink3 border-b bd-soft">
                    <th className="py-2">FY</th><th className="py-2 text-right">Actual</th><th className="py-2 text-right">BE</th><th className="py-2 text-right">RE</th></tr></thead>
                  <tbody>
                    {Object.entries(s.fin.years).map(([fy, v]) => (
                      <tr key={fy} className="border-b bd-soft last:border-0">
                        <td className="py-2 f-mono tx-ink2">{fy}</td>
                        {["actual", "be", "re"].map((k) => (
                          <td key={k} className="py-2 text-right f-mono font-semibold tx-ink">{v[k] != null ? v[k].toLocaleString("en-IN") : <span className="tx-ink3 font-normal">—</span>}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
                {reVsBe(s) != null && (
                  <div className="t11 tx-ink2 bg-paper rounded-lg px-3 py-2 mt-3 border bd-soft">
                    RE 2025-26 = <strong className="f-mono tx-emd">{reVsBe(s)}%</strong> of BE 2025-26 — same official series; Actuals, BE and RE are never mixed.
                  </div>
                )}
                <p className="t10 tx-ink3 mt-2">Scheme-level sanctioned/released/utilised: {NR} in these sources.</p>
              </>
            ) : (
              <p className="text-sm tx-ink3 italic">Scheme-level financials not reported in this import. No estimate is shown in place of official data.</p>
            )}
          </div>
        </div>

        {/* RIGHT: prominent match/action rail */}
        <div className="space-y-4 lg:sticky lg:top-6">
          <div className="card-d p-6">
            <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-1">Your match</div>
            {m && m.pct != null ? (
              <>
                <div className="f-mono font-bold tx-em" style={{ fontSize: "3rem", lineHeight: 1 }}>{m.pct}%</div>
                <div className="t11 tx-dim mt-1">Official criteria matched <strong className="tx-bright f-mono">{m.matched}/{m.evaluable}</strong> · {m.manual} manual</div>
              </>
            ) : s.criteria ? (
              <p className="t11 tx-dim">Complete <button onClick={() => go("find")} className="tx-cy font-medium hover:underline">Find My Subsidy</button> to test your profile against this scheme's verified criteria.</p>
            ) : (
              <p className="t11 tx-dim italic">Criteria not reported in this import — see official source for authoritative rules.</p>
            )}
            {s.criteria && (
              <div className="space-y-2 mt-4">
                {(m ? m.parts : s.criteria.map((c) => ({ text: c.text, state: c.check ? "unchecked" : "manual" }))).map((p, i) => (
                  <div key={i} className="flex items-start gap-2 rounded-lg p-2.5 bg-navy3 border bd-line">
                    {p.state === "pass" ? <CheckCircle2 className="w-4 h-4 tx-em shrink-0 mt-0.5" />
                      : p.state === "fail" ? <XCircle className="w-4 h-4 tx-rd shrink-0 mt-0.5" />
                      : p.state === "manual" ? <CircleHelp className="w-4 h-4 tx-dim2 shrink-0 mt-0.5" />
                      : <CircleSlash className="w-4 h-4 tx-dim2 shrink-0 mt-0.5" />}
                    <div className="t11 tx-dim leading-snug">{p.text}{p.state === "manual" && <span className="t9 f-mono tx-dim2 block">Manual verification</span>}</div>
                  </div>
                ))}
              </div>
            )}
            {s.application_url ? (
              <a href={s.application_url} target="_blank" rel="noopener noreferrer" className="btn-em mt-4 inline-flex items-center justify-center gap-2 w-full font-semibold rounded-xl px-4 py-2.5 text-sm focus:outline-none">
                Apply on official website <ExternalLink className="w-4 h-4" />
              </a>
            ) : (
              <div className="t11 tx-dim italic mt-4">Official application URL not in this import — apply via the source below.</div>
            )}
          </div>
          <div className="card-d p-5">
            <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-2">Data availability</div>
            <div className="space-y-1.5">
              {availability.map(([k, ok]) => (
                <div key={k} className="flex items-center justify-between t11">
                  <span className="tx-dim">{k}</span>
                  {ok ? <span className="inline-flex items-center gap-1 tx-em font-medium"><CheckCircle2 className="w-3.5 h-3.5" /> Available</span>
                    : <span className="inline-flex items-center gap-1 tx-dim2"><XCircle className="w-3.5 h-3.5" /> {NR}</span>}
                </div>
              ))}
              <div className="flex items-center justify-between t11">
                <span className="tx-dim">Combination rule</span>
                {comboRule ? <span className="tx-em font-medium">On record</span> : <span className="tx-wn">Not established</span>}
              </div>
            </div>
            <div className="mt-3">
              <div className="h-1.5 rounded-full bg-navy3 overflow-hidden"><div className="h-full bg-em rounded-full bar-anim" style={{ width: `${conf.pts}%` }} /></div>
              <p className="t9 f-mono tx-dim2 mt-1">DATA CONFIDENCE {conf.pts}/100 — record completeness, not scheme trustworthiness</p>
            </div>
          </div>
          <div className="card-d p-5 t11 tx-dim space-y-1">
            <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-1.5">Data source</div>
            <div><span className="tx-dim2">Source:</span> <span className="tx-bright font-medium">{s.source_org}</span></div>
            <div><span className="tx-dim2">Type:</span> {s.source_type}</div>
            <div><span className="tx-dim2">Last verified:</span> <span className="f-mono tx-cy">{s.last_verified}</span></div>
            <a href={s.official_source_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 tx-cy hover:underline font-medium">Open official source <ExternalLink className="w-3 h-3" /></a>
          </div>
          {s.documents && (
            <div className="card-d p-5">
              <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-2">Documents typically required</div>
              <ul className="t11 tx-dim space-y-1">{s.documents.map((d) => <li key={d} className="flex gap-1.5"><ScrollText className="w-3.5 h-3.5 tx-dim2 shrink-0 mt-0.5" />{d}</li>)}</ul>
            </div>
          )}
        </div>
      </div>
      <MatchDisclaimer dark />
      <Disclaimer dark />
    </div>
  );
}

/* ================================================================== */
/*  COMBINATION CHECKER                                                */
/* ================================================================== */
export function ComboChecker() {
  const [aId, setA] = useState("PMEGP");
  const [bId, setB] = useState("PMFME");
  const a = SCHEMES.find((s) => s.id === aId);
  const b = SCHEMES.find((s) => s.id === bId);
  const v = combineVerdict(a, b);
  const style = {
    allowed: { icon: <CheckCircle2 className="w-8 h-8 tx-em" />, label: "Explicitly allowed", c: "var(--em)" },
    conditional: { icon: <AlertTriangle className="w-8 h-8 tx-wn" />, label: "Conditional / requires verification", c: "var(--wn)" },
    prohibited: { icon: <XCircle className="w-8 h-8 tx-rd" />, label: "Explicitly prohibited", c: "var(--rd)" },
    unknown: { icon: <CircleHelp className="w-8 h-8 tx-dim2" />, label: "Compatibility not established", c: "var(--dim2)" },
    invalid: { icon: <CircleSlash className="w-8 h-8 tx-dim2" />, label: "Same scheme selected", c: "var(--dim2)" },
  }[v.status];
  const selCls = "w-full rounded-xl border bd-line px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 tx-bright";
  return (
    <div className="fade-in space-y-5 max-w-3xl mx-auto">
      <div>
        <Eyebrow dark>Anti-stacking rules — official evidence only</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">Can I combine these subsidies?</h1>
        <p className="text-sm tx-dim mt-1">Subsidy360 never infers compatibility. A verdict appears only where an official rule is on record; everything else is honestly "not established".</p>
      </div>
      <div className="card-d p-6 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          {[["Subsidy A", aId, setA], ["Subsidy B", bId, setB]].map(([label, val, setter]) => (
            <label key={label} className="text-sm"><span className="block tx-dim mb-1.5 font-medium">{label}</span>
              <select className={selCls} style={{ background: "var(--navy3)" }} value={val} onChange={(e) => setter(e.target.value)}>
                {SCHEMES.map((s) => <option key={s.id} value={s.id}>{s.name.split("(")[0].trim()}</option>)}
              </select></label>
          ))}
        </div>
        <div className="rounded-2xl p-5 flex items-start gap-4 border bg-navy3" style={{ borderColor: style.c }}>
          {style.icon}
          <div className="min-w-0">
            <div className="font-bold text-lg tx-bright">{style.label}</div>
            <p className="text-sm tx-dim leading-relaxed mt-1">{v.rule}</p>
            {v.source && (
              <div className="mt-3 rounded-xl p-3 t11 tx-dim border bd-line bg-navy2 space-y-0.5">
                <div className="f-mono t10 uppercase tracking-widest tx-gd">Evidence</div>
                <div><span className="tx-dim2">Official source:</span> <span className="font-medium tx-bright">{v.source}</span></div>
                <div><span className="tx-dim2">Last verified:</span> <span className="f-mono">{v.verified}</span></div>
                <a href={v.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 tx-cy hover:underline font-medium">Open official rule <ExternalLink className="w-3 h-3" /></a>
              </div>
            )}
          </div>
        </div>
        <div className="text-xs tx-dim leading-relaxed">
          <strong className="tx-bright">Rules currently on record:</strong> PMEGP's prohibition on availing subsidy under any other
          Central/State scheme for the same unit, and SISFS's ₹10 lakh prior-support ceiling. All other pairings return
          "not established" until an official rule is imported.
        </div>
      </div>
      <Disclaimer dark />
    </div>
  );
}

/* ================================================================== */
/*  PUBLIC MONEY — money-flow panel, FY analysis, coverage grid        */
/* ================================================================== */
export const TILE_STATES = ["JK", "HP", "PB", "UK", "HR", "DL", "RJ", "UP", "BR", "SK", "AS", "GJ", "MP", "JH", "WB", "MH", "CG", "OD", "TS", "AP", "GA", "KA", "TN", "KL", "Other UTs"];
export function PublicMoney({ openScheme }) {
  const withFin = SCHEMES.filter((s) => s.fin);
  const [selId, setSelId] = useState("PMKISAN");
  const [fy, setFy] = useState("2026-27");
  const sel = SCHEMES.find((s) => s.id === selId);
  const y = sel.fin?.years || {};
  const FYS = [
    { id: "2024-25", types: [["actual", "Actuals"]] },
    { id: "2025-26", types: [["be", "Budget Estimate"], ["re", "Revised Estimate"]] },
    { id: "2026-27", types: [["be", "Budget Estimate"]] },
  ];
  const cur = FYS.find((f) => f.id === fy);
  const rows = withFin.map((s) => ({ s, v: s.fin.years[fy] || {} }));
  const chart = rows.map(({ s, v }) => { const o = { name: s.id }; cur.types.forEach(([k, label]) => { o[label] = v[k] ?? 0; }); return o; })
    .filter((o) => cur.types.some(([, l]) => o[l] > 0)).sort((a, b) => (b[cur.types[0][1]] || 0) - (a[cur.types[0][1]] || 0));
  const sectorBE = useMemo(() => {
    const m = {};
    withFin.forEach((s) => { const v = beOf(s, "2026-27"); if (v != null) { m[s.sector] = m[s.sector] || { name: s.sector, value: 0 }; m[s.sector].value += v; } });
    return Object.values(m).sort((a, b) => b.value - a.value);
  }, []);
  const alloc = fy === "2024-25" ? y["2024-25"]?.actual : y[fy]?.be;
  const allocLabel = fy === "2024-25" ? "ACTUAL EXPENDITURE" : "ALLOCATED (BE)";
  const yy = y[fy] || {};
  const flow = [
    { l: allocLabel, v: alloc, src: true }, { l: "SANCTIONED", v: yy.sanctioned ?? null }, { l: "RELEASED", v: yy.released ?? null }, { l: "UTILISED", v: yy.utilised ?? null },
  ];
  return (
    <div className="fade-in space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <Eyebrow dark>Public money — official figures only</Eyebrow>
          <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">Public Money Dashboard</h1>
          <p className="text-sm tx-dim mt-1">Every number is a labelled BE, RE or Actual from Union Budget documents. Unpublished stages say NOT REPORTED — never computed or invented.</p>
        </div>
        <ImportBadge dark />
      </div>

      {/* WHERE DOES THE MONEY GO? */}
      <div className="card-d p-6 md:p-8 relative overflow-hidden">
        <div className="absolute inset-0 hero-grid opacity-40" aria-hidden="true" />
        <div className="relative">
          <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
            <h2 className="f-display text-xl md:text-2xl font-bold tx-bright">Where does the money go?</h2>
            <div className="flex gap-2 flex-wrap">
              <select className="rounded-xl border bd-line px-3 py-2 text-sm tx-bright focus:outline-none focus:ring-2 focus:ring-cyan-400" style={{ background: "var(--navy3)" }} value={selId} onChange={(e) => setSelId(e.target.value)}>
                {withFin.map((s) => <option key={s.id} value={s.id}>{s.name.split("(")[0].trim()}</option>)}
              </select>
              <div className="flex gap-1.5">
                {FYS.map((f) => (
                  <button key={f.id} onClick={() => setFy(f.id)} className={`f-mono t11 rounded-lg px-3 py-2 border focus:outline-none ${fy === f.id ? "tx-gd" : "btn-ghost-d"}`} style={fy === f.id ? { borderColor: "var(--gd)", background: "rgba(231,183,91,.1)" } : {}}>{f.id}</button>
                ))}
              </div>
            </div>
          </div>
          <div className="grid md:grid-cols-4 gap-0 md:gap-2 items-stretch">
            {flow.map((f, i) => (
              <React.Fragment key={f.l}>
                <div className="relative rounded-2xl border p-5 text-center bg-navy3" style={{ borderColor: i === 0 && f.v != null ? "var(--cy)" : "var(--line)" }}>
                  <div className={`f-mono font-bold ${f.v != null ? "tx-gd text-2xl md:text-3xl" : "tx-dim2 text-sm italic mt-1"}`}>{f.v != null ? cr(f.v) : "NOT REPORTED"}</div>
                  <div className="f-mono t10 uppercase tracking-widest tx-dim2 mt-2">{f.l}</div>
                  <div className="mt-2">{f.v != null && f.src ? <SourceInfo dark name={BUDGET_SRC.name} url={BUDGET_SRC.url} /> : <Chip kind="chip-nr-d">No official figure</Chip>}</div>
                  {i < flow.length - 1 && (
                    <>
                      <ArrowRight className="hidden md:block absolute top-1/2 -translate-y-1/2 w-5 h-5 tx-dim2" style={{ right: -18 }} />
                      <ArrowDown className="md:hidden mx-auto mt-3 w-5 h-5 tx-dim2" />
                    </>
                  )}
                </div>
              </React.Fragment>
            ))}
          </div>
          <p className="t10 f-mono tx-dim2 mt-4">{fy === "2025-26" && y["2025-26"]?.re != null ? `RE 2025-26: ${cr(y["2025-26"].re)} · RE ÷ BE = ${reVsBe(sel)}% (same official series)` : "Union Budget documents publish allocation/expenditure estimates — not scheme-level sanction, release or utilisation stages."} <button onClick={() => openScheme(sel.id)} className="tx-cy hover:underline ml-1">View record →</button></p>
        </div>
      </div>

      {/* FY chart + table */}
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="card-d p-6">
          <h3 className="font-semibold tx-bright mb-1">Scheme-wise figures, FY {fy} (₹ Cr)</h3>
          <p className="t10 f-mono tx-dim2 mb-2">Estimate types labelled · never mixed</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={chart}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID_D} />
              <XAxis dataKey="name" tick={AXIS_D} axisLine={{ stroke: GRID_D }} tickLine={false} />
              <YAxis tick={AXIS_D} width={56} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(143,166,184,.08)" }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              {cur.types.map(([, label], i) => <Bar key={label} dataKey={label} fill={[CH.alloc, CH.util][i]} radius={[3, 3, 0, 0]} />)}
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card-d p-6">
          <h3 className="font-semibold tx-bright mb-2">Sector-wise BE 2026-27 in the import (₹ Cr)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={sectorBE} dataKey="value" nameKey="name" innerRadius={58} outerRadius={98} paddingAngle={2} stroke="var(--navy2)">
                {sectorBE.map((_, i) => <Cell key={i} fill={[CH.alloc, CH.util, CH.bench, CH.deep, "#7FD1DE", "#5BC9A5", "#C9A24A", "#3E7A93", "#8FA6B8"][i % 9]} />)}
              </Pie>
              <Tooltip content={<ChartTip />} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
            </PieChart>
          </ResponsiveContainer>
          <p className="t10 tx-dim2">Covers only schemes in this import — not total government spending by sector.</p>
        </div>
      </div>

      {/* Coverage grid */}
      <div className="card-d p-6">
        <div className="flex items-center gap-2 mb-1"><Grid3x3 className="w-4 h-4 tx-cy" /><h3 className="font-semibold tx-bright">State & UT coverage — abstract grid</h3></div>
        <p className="t11 tx-dim mb-4">All {SCHEMES.length} imported schemes are Central and apply across States/UTs. State-level allocation and utilisation splits: <span className="italic">{NR}</span> in this import — tiles are intentionally uniform rather than shaded with invented intensity. (An abstract grid is used instead of a geographic map to avoid inaccurate boundaries.)</p>
        <div className="grid grid-cols-5 sm:grid-cols-8 lg:grid-cols-13 gap-1.5" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(52px,1fr))" }}>
          {TILE_STATES.map((st) => (
            <div key={st} className="rounded-lg border bd-line bg-navy3 p-2 text-center lift" title={`${SCHEMES.length} Central schemes applicable · state-level data: Not reported`}>
              <div className="f-mono t11 font-semibold tx-cy">{st}</div>
              <div className="f-mono t9 tx-dim2">{SCHEMES.length}</div>
            </div>
          ))}
        </div>
        <div className="t9 f-mono tx-dim2 mt-2">Tile value = Central schemes applicable · Data freshness {IMPORT_DATE}</div>
      </div>
      <Disclaimer dark />
    </div>
  );
}

/* ================================================================== */
/*  ECONOMIC IMPACT — dark editorial                                   */
/* ================================================================== */
export function Impact() {
  const chain = ["Government expenditure", "Lower effective cost", "Higher incentive", "Potential investment", "Potential production", "Potential employment"];
  return (
    <div className="fade-in space-y-6 max-w-4xl mx-auto">
      <div>
        <Eyebrow dark>Editorial · the economics behind the platform</Eyebrow>
        <h1 className="f-display text-2xl md:text-4xl font-bold tx-bright">From subsidy to economic impact</h1>
      </div>
      <div className="card-d p-6 md:p-8">
        <div className="flex flex-col items-stretch gap-0">
          {chain.map((c, i) => (
            <React.Fragment key={c}>
              <div className={`rounded-xl border p-4 text-center f-display font-bold ${i === 0 ? "tx-gd" : i < 3 ? "tx-cy" : "tx-em"}`} style={{ borderColor: "var(--line)", background: "var(--navy3)", fontSize: "1.05rem" }}>
                {c}
                <div className="f-mono t9 uppercase tracking-widest tx-dim2 font-normal mt-1">{i === 0 ? "Official data (budget documents)" : "Subsidy360 scenario analysis — mechanism, not measured outcome"}</div>
              </div>
              {i < chain.length - 1 && <div className="mx-auto w-px h-5" style={{ background: "linear-gradient(180deg,var(--cy),transparent)" }} />}
            </React.Fragment>
          ))}
        </div>
      </div>
      {[
        ["Information asymmetry", "A citizen may qualify for a government benefit and simply not know it exists — the administrator holds far more information than the applicant. Subsidy360 shrinks the gap with searchable verified records, plain-language criteria and a transparent match score — and is equally transparent about what it does not know ('Not reported')."],
        ["Public finance: BE → RE → Actuals", "A Budget Estimate is the plan, a Revised Estimate is the mid-year correction, and Actuals are what was really spent. Reading the three for the same scheme reveals implementation pace without inventing any 'utilisation' figure the sources don't publish — see MGNREGS (₹88,000 Cr RE against a ₹30,000 Cr next-year BE) or Jal Jeevan Mission (₹67,000 Cr BE revised to ₹17,000 Cr)."],
        ["Subsidies as incentives", "A subsidy lowers the effective price of a chosen activity, shifting private decisions toward what policy wants more of — investment (PMEGP margin money), production (PMFME capital subsidy), clean-energy adoption (PM Surya Ghar), or income floors (PM-KISAN). Anti-stacking rules like PMEGP's other-subsidy prohibition exist precisely because double-paying one incentive distorts resource allocation instead of correcting it."],
        ["Utilisation efficiency", "Where comparable official data exists, Utilisation Rate = Actual Expenditure ÷ Relevant Allocation × 100 — and the calculation must declare whether it uses BE, RE or Actuals. In this import the closest published comparison is RE vs BE 2025-26; a steep downward revision can signal awareness gaps, eligibility barriers, administrative delays, low demand or implementation issues — each worth investigating, none assumable."],
      ].map(([h, t]) => (
        <div key={h} className="card-d p-6">
          <h3 className="f-display font-bold tx-bright mb-2 text-lg">{h}</h3>
          <p className="text-sm tx-dim leading-relaxed">{t}</p>
        </div>
      ))}
    </div>
  );
}

/* ================================================================== */
/*  COMPARE                                                            */
/* ================================================================== */
export function CompareSchemes({ profile, openScheme }) {
  const [sel, setSel] = useState(["PMEGP", "PMFME", "SISFS"]);
  const toggle = (id) => setSel((x) => x.includes(id) ? x.filter((y) => y !== id) : x.length < 3 ? [...x, id] : x);
  const chosen = SCHEMES.filter((s) => sel.includes(s.id));
  const rows = [
    ["Benefit", (s) => s.benefit_summary ? <span className="t11 leading-snug block">{s.benefit_summary}</span> : <NRRow />],
    ["Subsidy %", (s) => s.subsidy_pct ? <span className="f-mono">{s.subsidy_pct}</span> : <NRRow />],
    ["Maximum benefit", (s) => s.max_benefit != null ? <span className="f-mono tx-gd font-semibold">{inr(s.max_benefit)}</span> : <NRRow />],
    ["Target beneficiary", (s) => s.beneficiary.join(", ")],
    ["Eligibility (profile)", (s) => {
      if (!s.criteria) return <NRRow />;
      if (!profile) return <span className="t11 tx-ink3">Run Find My Subsidy</span>;
      const m = matchScheme(s, profile);
      return <span className="f-mono">{m.matched}/{m.evaluable}{m.pct != null ? ` · ${m.pct}%` : ""}</span>;
    }],
    ["Loan-linked", (s) => s.benefit_summary ? (s.loan_linked ? "Yes" : "No") : <NRRow />],
    ["Application", (s) => s.application_url ? <a className="tx-cyd hover:underline inline-flex items-center gap-1" href={s.application_url} target="_blank" rel="noopener noreferrer">Official portal <ExternalLink className="w-3 h-3" /></a> : <NRRow />],
    ["BE 2026-27", (s) => beOf(s, "2026-27") != null ? <span className="f-mono">{cr(beOf(s, "2026-27"))}</span> : <NRRow />],
    ["RE vs BE 2025-26", (s) => reVsBe(s) != null ? <span className="f-mono">{reVsBe(s)}%</span> : <NRRow />],
    ["Utilisation data", () => <NRRow />],
    ["Combination rule", (s) => COMBO_RULES.find((r) => r.ids.includes(s.id)) ? "Official rule on record" : <span className="tx-wn" style={{ color: "#8A6114" }}>Not established</span>],
    ["Data confidence", (s) => <span className="f-mono">{dataConfidence(s).pts}/100</span>],
    ["Last verified", (s) => <span className="f-mono">{s.last_verified}</span>],
  ];
  return (
    <div className="fade-in space-y-5">
      <div>
        <Eyebrow dark>Side-by-side, sources intact</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">Compare Schemes</h1>
        <p className="text-sm tx-dim mt-1">Missing values stay missing — no scheme is ranked on invented figures, so no artificial "winner" is declared where data isn't comparable.</p>
      </div>
      <div className="card-d p-4">
        <div className="flex flex-wrap gap-2">
          {SCHEMES.map((s) => (
            <button key={s.id} onClick={() => toggle(s.id)} className={`text-xs rounded-full border px-3 py-1.5 f-mono font-medium transition-colors focus:outline-none ${sel.includes(s.id) ? "tx-em" : "btn-ghost-d"}`} style={sel.includes(s.id) ? { borderColor: "var(--em)", background: "rgba(24,185,129,.12)" } : {}}>{s.id}</button>
          ))}
        </div>
        <div className="text-xs tx-dim2 mt-2 f-mono">{sel.length}/3 selected</div>
      </div>
      {chosen.length >= 2 ? (
        <div className="card-l overflow-x-auto scroll-thin">
          <table className="w-full text-sm" style={{ minWidth: 640 }}>
            <thead><tr className="border-b bd-soft">
              <th className="text-left p-4 f-mono t10 uppercase tracking-wider tx-ink3" style={{ width: 150 }}>Feature</th>
              {chosen.map((s) => (
                <th key={s.id} className="text-left p-4 align-top">
                  <div className="f-mono t10 tx-ink3">{s.id}</div>
                  <div className="font-semibold tx-ink leading-snug">{s.name.split("(")[0].trim()}</div>
                  <button onClick={() => openScheme(s.id)} className="t11 tx-cyd hover:underline mt-1">Open record</button>
                </th>
              ))}
            </tr></thead>
            <tbody>
              {rows.map(([label, fn]) => (
                <tr key={label} className="border-b bd-soft last:border-0 align-top">
                  <td className="p-4 tx-ink3">{label}</td>
                  {chosen.map((s) => <td key={s.id} className="p-4 font-medium tx-ink">{fn(s)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="card-d p-8 text-center text-sm tx-dim">Select at least two schemes above to build the comparison table.</div>
      )}
    </div>
  );
}


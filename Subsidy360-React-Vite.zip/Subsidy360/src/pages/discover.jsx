import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  Legend, PieChart, Pie, Cell,
} from "recharts";
import {
  LayoutDashboard, Search, Compass, ListChecks, GitMerge, Landmark, Scale,
  BookOpen, Info, Menu, X, ChevronRight, ChevronLeft, CheckCircle2, AlertTriangle,
  XCircle, ArrowRight, ArrowDown, MapPin, Users, Wallet, TrendingUp, Layers, Sparkles,
  FileText, BadgeCheck, CircleDollarSign, PlayCircle, Filter, RotateCcw,
  ExternalLink, Database, ShieldCheck, CircleHelp, CalendarDays, Library,
  ScrollText, CircleSlash, FlaskConical, Bot, SlidersHorizontal, Radar, Grid3x3,
  Send,
} from "lucide-react";
import { SCHEMES, loadExternalSchemes } from "../data";
import { IMPORT_DATE, BUDGET_SRC } from "../data/financials";
import { SOURCES, COMBO_RULES, RADAR } from "../data/sources";
import { inr, cr, NR, matchScheme, dataConfidence, reVsBe, beOf, combineVerdict,
  SECTORS, BEN_TYPES, INCOME_BANDS, STATES, DEMO_PROFILE, BLANK } from "../engine";
import { Logo, Eyebrow, Chip, StatusChip, SourceInfo, Field, NRRow, ChartTip,
  CH, AXIS_D, GRID_D, Disclaimer, ImportBadge, MatchDisclaimer, SchemeCard } from "../components/shared";
import { useCountUp } from "../hooks";

/* ================================================================== */
/*  DASHBOARD — dark shell, premium hero                               */
/* ================================================================== */
export function HeroBackdrop() {
  const nodes = [[12, 18, 5], [28, 64, 4], [46, 30, 6], [63, 70, 4], [78, 24, 5], [88, 56, 4], [55, 12, 3], [20, 42, 3]];
  return (
    <div className="absolute inset-0 hero-grid overflow-hidden" aria-hidden="true">
      {nodes.map(([x, y, s], i) => <span key={i} className="node" style={{ left: `${x}%`, top: `${y}%`, width: s, height: s }} />)}
      <span className="dataline" style={{ left: "8%", right: "40%", top: "26%" }} />
      <span className="dataline" style={{ left: "30%", right: "10%", top: "58%" }} />
      <span className="dataline" style={{ left: "15%", right: "25%", top: "78%" }} />
      <div className="absolute inset-0" style={{ background: "radial-gradient(1200px 500px at 70% -10%, rgba(34,184,207,.10), transparent 60%), radial-gradient(900px 420px at 10% 110%, rgba(24,185,129,.08), transparent 55%)" }} />
    </div>
  );
}

export function KPI({ eyebrow, value, sub, delta, accent, source }) {
  return (
    <div className="card-d lift p-5 relative">
      <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-2">{eyebrow}</div>
      <div className={`f-mono text-2xl md:text-3xl font-bold ${accent || "tx-bright"}`}>{value}</div>
      <div className="t11 tx-dim mt-1">{sub}</div>
      {delta && <div className="t11 f-mono mt-1 tx-em">{delta}</div>}
      {source && <div className="mt-2">{source}</div>}
    </div>
  );
}

export function Dashboard({ go, openScheme }) {
  const withFin = SCHEMES.filter((s) => s.fin);
  const totalBE27 = withFin.reduce((t, s) => t + (beOf(s, "2026-27") ?? 0), 0);
  const nSchemes = useCountUp(SCHEMES.length, 700);
  const nSources = useCountUp(new Set(SCHEMES.map((s) => s.official_source_url)).size, 800);
  const nFin = useCountUp(withFin.length, 900);
  const beAnim = useCountUp(totalBE27, 1100);
  const featured = ["PMKISAN", "PMSG", "PMEGP", "SISFS"].map((id) => SCHEMES.find((s) => s.id === id));
  const chartData = [...withFin.filter((s) => beOf(s, "2026-27") != null)].sort((a, b) => beOf(b, "2026-27") - beOf(a, "2026-27")).slice(0, 6)
    .map((s) => { const y = s.fin.years["2025-26"] || {}; return { name: s.id, "BE 2025-26": y.be ?? 0, "RE 2025-26": y.re ?? 0, "BE 2026-27": beOf(s, "2026-27") ?? 0 }; });
  return (
    <div className="fade-in space-y-8">
      {/* HERO */}
      <div className="relative overflow-hidden rounded-3xl bg-navy2 border bd-line">
        <HeroBackdrop />
        <div className="relative p-8 md:p-14 max-w-3xl">
          <Eyebrow dark>Evidence-based public-finance intelligence · Academic prototype</Eyebrow>
          <h1 className="f-display font-bold tx-bright" style={{ fontSize: "clamp(2.6rem,6vw,4.2rem)", lineHeight: 1.05 }}>
            Subsidy<span className="tx-em">360</span>
          </h1>
          <p className="f-mono text-sm tracking-widest uppercase tx-cy mt-3">Discover. Qualify. Compare. Understand.</p>
          <p className="tx-dim mt-5 leading-relaxed text-base md:text-lg" style={{ maxWidth: 560 }}>
            India's government schemes, eligibility intelligence and public-money data — brought together in one
            evidence-based interface.
          </p>
          <div className="flex flex-wrap gap-3 mt-7">
            <button onClick={() => go("find")} className="btn-em inline-flex items-center gap-2 font-semibold rounded-xl px-6 py-3 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-300">
              Find My Subsidy <ArrowRight className="w-4 h-4" />
            </button>
            <button onClick={() => go("money")} className="btn-ghost-d inline-flex items-center gap-2 font-semibold rounded-xl px-6 py-3 transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-300">
              <Landmark className="w-4 h-4" /> Explore Public Money
            </button>
          </div>
        </div>
        {/* DATA STRIP */}
        <div className="relative border-t bd-line grid grid-cols-2 md:grid-cols-4 divide-x" style={{ divideColor: "var(--line)" }}>
          {[
            { v: nSchemes, l: "Schemes indexed*", m: true },
            { v: nSources, l: "Official sources*", m: true },
            { v: nFin, l: "Budget datasets*", m: true },
            { v: IMPORT_DATE, l: "Data freshness — verified import", m: false },
          ].map((x, i) => (
            <div key={i} className="p-4 md:p-5" style={{ borderColor: "var(--line)" }}>
              <div className={`f-mono font-bold ${x.m ? "text-2xl tx-gd" : "text-sm tx-em"}`}>{x.v}</div>
              <div className="f-mono t10 uppercase tracking-widest tx-dim2 mt-1">{x.l}</div>
            </div>
          ))}
        </div>
        <div className="relative px-5 pb-3 pt-2 t10 tx-dim2 f-mono">*Computed live from the connected verified dataset — no invented statistics. No live API in this build: prototype synchronization, not "live" data.</div>
      </div>

      {/* KPI ROW */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPI eyebrow="Government allocation" value={cr(beAnim)} sub={`FY 2026-27 BE · ${withFin.length} schemes in import`} accent="tx-gd"
          source={<SourceInfo dark name={BUDGET_SRC.name} url={BUDGET_SRC.url} />} />
        <KPI eyebrow="Fully verified records" value={SCHEMES.filter((s) => s.data_status === "verified").length} sub="benefit + criteria + application verified" accent="tx-em" />
        <KPI eyebrow="Scheme-level utilisation" value={<span className="text-lg italic tx-dim">{NR}</span>} sub="not published in these sources — never invented" />
        <KPI eyebrow="Last verified" value={<span className="text-xl">{IMPORT_DATE}</span>} sub="official sources, research import" accent="tx-cy" />
      </div>

      {/* CHART + NOTE */}
      <div className="grid lg:grid-cols-5 gap-4">
        <div className="card-d p-6 lg:col-span-3">
          <Eyebrow dark>Union Budget series</Eyebrow>
          <h3 className="font-semibold tx-bright mb-3">Six largest budget lines — BE vs RE vs next-year BE (₹ Cr)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID_D} />
              <XAxis dataKey="name" tick={AXIS_D} axisLine={{ stroke: GRID_D }} tickLine={false} />
              <YAxis tick={AXIS_D} width={54} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(143,166,184,.08)" }} />
              <Legend wrapperStyle={{ fontSize: 11, color: "#8FA6B8" }} />
              <Bar dataKey="BE 2025-26" fill={CH.alloc} radius={[3, 3, 0, 0]} />
              <Bar dataKey="RE 2025-26" fill={CH.util} radius={[3, 3, 0, 0]} />
              <Bar dataKey="BE 2026-27" fill={CH.bench} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <p className="t10 tx-dim2 mt-1 f-mono">Source: Union Budget 2026-27 documents · zero bar = estimate type not reported</p>
        </div>
        <div className="card-l p-6 lg:col-span-2">
          <Eyebrow>Reading the terminal</Eyebrow>
          <h3 className="font-semibold tx-ink mb-2">Budgeted vs revised</h3>
          <p className="text-sm tx-ink2 leading-relaxed">
            A Budget Estimate is the plan; a Revised Estimate is what the government now expects to spend. The gap
            between the cyan and emerald bars is the most honest published signal of implementation pace — no invented
            "utilisation" required.
          </p>
          <button onClick={() => go("money")} className="mt-3 text-sm font-medium tx-cyd hover:underline inline-flex items-center gap-1">
            Open Public Money <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* FEATURED */}
      <div>
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <h2 className="f-display text-xl font-bold tx-bright">Fully verified scheme records</h2>
          <button onClick={() => go("schemes")} className="text-sm font-medium tx-cy hover:underline">Browse all {SCHEMES.length} schemes →</button>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {featured.map((s) => <SchemeCard key={s.id} s={s} onOpen={() => openScheme(s.id)} />)}
        </div>
      </div>
      <Disclaimer dark />
    </div>
  );
}

/* ================================================================== */
/*  FIND MY SUBSIDY                                                    */
/* ================================================================== */

export function FindSubsidy({ profile, setProfile, results, setResults, openScheme, go }) {
  const [step, setStep] = useState(results ? 4 : 1);
  const [form, setForm] = useState(profile || BLANK);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const inputCls = "w-full rounded-xl border bd-soft px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-300 bg-card tx-ink";
  const OptionCard = ({ label, selected, onClick }) => (
    <button onClick={onClick} className={`rounded-2xl border p-3.5 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-300 ${selected ? "tx-emd" : "bd-soft bg-card tx-ink2 hover:border-slate-400"}`}
      style={selected ? { borderColor: "var(--em)", background: "rgba(24,185,129,.08)" } : {}}>{label}</button>
  );
  const YN = ({ k, q }) => (
    <div>
      <div className="text-sm font-medium tx-ink2 mb-2">{q}</div>
      <div className="flex gap-3">{["Yes", "No"].map((v) => <OptionCard key={v} label={v} selected={form[k] === v} onClick={() => set(k, v)} />)}</div>
    </div>
  );
  const condOk =
    form.userType === "Farmer" ? !!form.landholding :
    form.userType === "Household" ? !!form.electricity :
    form.userType === "Startup" ? !!form.dpiit && !!form.incorpUnder2 :
    ["MSME", "Entrepreneur", "Self-employed"].includes(form.userType) ? !!form.foodProcessing : true;
  const canNext =
    step === 1 ? form.state && form.district.trim() :
    step === 2 ? !!form.userType && condOk :
    step === 3 ? form.incomeMax && form.investment !== "" && form.loan && form.status : true;
  const run = (p) => {
    const prof = { ...p, investment: Number(p.investment) || 0 };
    const scored = SCHEMES.map((s) => ({ s, m: matchScheme(s, prof) })).sort((a, b) => (b.m.pct ?? -1) - (a.m.pct ?? -1) || b.m.matched - a.m.matched);
    setProfile(prof); setResults(scored); setStep(4);
  };
  const reset = () => { setForm(BLANK); setProfile(null); setResults(null); setStep(1); };
  const steps = ["Location", "Applicant", "Finances", "Results"];
  return (
    <div className="fade-in space-y-6 max-w-3xl mx-auto">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <Eyebrow dark>Discovery questionnaire</Eyebrow>
          <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">Find My Subsidy</h1>
          <p className="text-sm tx-dim mt-1">Only the questions needed to screen the imported schemes — no unnecessary personal data.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { setForm(DEMO_PROFILE); run(DEMO_PROFILE); }} className="inline-flex items-center gap-1.5 text-sm font-medium rounded-xl px-3.5 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-300 text-white" style={{ background: "var(--cy-deep)" }}>
            <PlayCircle className="w-4 h-4" /> Run demo profile
          </button>
          {(results || step > 1) && (
            <button onClick={reset} className="btn-ghost-d inline-flex items-center gap-1.5 text-sm font-medium rounded-xl px-3.5 py-2 focus:outline-none">
              <RotateCcw className="w-4 h-4" /> Start over
            </button>
          )}
        </div>
      </div>
      <div className="flex items-center gap-1.5">
        {steps.map((s, i) => (
          <div key={s} className="flex-1">
            <div className="h-1.5 rounded-full bar-anim" style={{ background: i + 1 <= step ? "var(--em)" : "var(--line)" }} />
            <div className={`f-mono t9 uppercase tracking-wide mt-1 hidden sm:block ${i + 1 === step ? "tx-em font-semibold" : "tx-dim2"}`}>{s}</div>
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="card-l p-6 space-y-4 rise">
          <h2 className="font-semibold tx-ink flex items-center gap-2"><MapPin className="w-4 h-4 tx-emd" /> Where are you based?</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <label className="text-sm"><span className="block tx-ink2 mb-1.5 font-medium">State</span>
              <select className={inputCls} value={form.state} onChange={(e) => set("state", e.target.value)}>
                <option value="">Select state…</option>{STATES.map((s) => <option key={s}>{s}</option>)}
              </select></label>
            <label className="text-sm"><span className="block tx-ink2 mb-1.5 font-medium">District</span>
              <input className={inputCls} placeholder="e.g., Ahmedabad" value={form.district} onChange={(e) => set("district", e.target.value)} /></label>
          </div>
          <p className="t11 tx-ink3">All schemes in the current import are Central (All-India). State schemes plug into the same record format when imported from official State sources.</p>
        </div>
      )}
      {step === 2 && (
        <div className="card-l p-6 space-y-5 rise">
          <h2 className="font-semibold tx-ink flex items-center gap-2"><Users className="w-4 h-4 tx-emd" /> Which best describes you?</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {BEN_TYPES.map((t) => <OptionCard key={t} label={t} selected={form.userType === t} onClick={() => set("userType", t)} />)}
          </div>
          {form.userType === "Farmer" && <YN k="landholding" q="Does your family hold cultivable land in its name?" />}
          {form.userType === "Household" && <YN k="electricity" q="Is there a valid electricity connection in the applicant's name?" />}
          {form.userType === "Startup" && (<div className="space-y-4"><YN k="dpiit" q="Is the startup DPIIT-recognised?" /><YN k="incorpUnder2" q="Was it incorporated within the last 2 years?" /></div>)}
          {["MSME", "Entrepreneur", "Self-employed"].includes(form.userType) && <YN k="foodProcessing" q="Is (or will) the enterprise be in food processing?" />}
        </div>
      )}
      {step === 3 && (
        <div className="card-l p-6 space-y-4 rise">
          <h2 className="font-semibold tx-ink flex items-center gap-2"><Wallet className="w-4 h-4 tx-emd" /> Financial details</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <label className="text-sm"><span className="block tx-ink2 mb-1.5 font-medium">Annual income range</span>
              <select className={inputCls} value={form.incomeLabel} onChange={(e) => { const b = INCOME_BANDS.find((x) => x.label === e.target.value); setForm((f) => ({ ...f, incomeLabel: b?.label || "", incomeMax: b?.max || null })); }}>
                <option value="">Select range…</option>{INCOME_BANDS.map((b) => <option key={b.label}>{b.label}</option>)}
              </select></label>
            <label className="text-sm"><span className="block tx-ink2 mb-1.5 font-medium">Project / investment amount (₹)</span>
              <input type="number" min="0" className={inputCls} placeholder="0 if not applicable" value={form.investment} onChange={(e) => set("investment", e.target.value)} /></label>
            <label className="text-sm"><span className="block tx-ink2 mb-1.5 font-medium">Existing or planned bank loan?</span>
              <select className={inputCls} value={form.loan} onChange={(e) => set("loan", e.target.value)}><option value="">Select…</option><option>Yes</option><option>No</option></select></label>
            <label className="text-sm"><span className="block tx-ink2 mb-1.5 font-medium">Project status</span>
              <select className={inputCls} value={form.status} onChange={(e) => set("status", e.target.value)}><option value="">Select…</option><option>Idea stage</option><option>New project</option><option>Expansion of existing activity</option><option>Not applicable</option></select></label>
          </div>
        </div>
      )}
      {step === 4 && results && (
        <div className="space-y-5">
          <div className="card-d p-5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="text-sm tx-dim">Profile: <strong className="tx-bright">{profile.userType}</strong> · {profile.district}, {profile.state} · investment <span className="f-mono tx-gd">{inr(profile.investment)}</span></div>
              <ImportBadge dark />
            </div>
            <div className="mt-3"><MatchDisclaimer dark /></div>
          </div>
          <h2 className="f-display text-xl font-bold tx-bright">Your scheme matches</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {results.filter((r) => r.m.pct != null).map((r) => <SchemeCard key={r.s.id} s={r.s} match={r.m} onOpen={() => openScheme(r.s.id)} />)}
          </div>
          <div className="card-d p-5">
            <h3 className="text-sm font-semibold tx-bright mb-1">Records without machine-checkable criteria in this import</h3>
            <p className="t11 tx-dim mb-3">Verified financials, full rulebooks not yet imported — listed for manual review rather than guessed at.</p>
            <div className="flex flex-wrap gap-2">
              {results.filter((r) => r.m.pct == null).map((r) => (
                <button key={r.s.id} onClick={() => openScheme(r.s.id)} className="t11 btn-ghost-d rounded-full px-3 py-1.5 font-medium focus:outline-none">{r.s.name.split("(")[0].trim()}</button>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <button onClick={() => go("combo")} className="btn-ghost-d inline-flex items-center gap-1.5 text-sm font-medium rounded-xl px-4 py-2 focus:outline-none"><GitMerge className="w-4 h-4" /> Check combination rules</button>
            <button onClick={() => go("whatif")} className="btn-ghost-d inline-flex items-center gap-1.5 text-sm font-medium rounded-xl px-4 py-2 focus:outline-none"><SlidersHorizontal className="w-4 h-4" /> Open What-If simulator</button>
          </div>
        </div>
      )}
      {step < 4 && (
        <div className="flex justify-between">
          <button disabled={step === 1} onClick={() => setStep(step - 1)} className="inline-flex items-center gap-1 text-sm font-medium tx-dim disabled:opacity-40 hover:tx-bright focus:outline-none"><ChevronLeft className="w-4 h-4" /> Back</button>
          {step < 3
            ? <button disabled={!canNext} onClick={() => setStep(step + 1)} className="btn-em inline-flex items-center gap-1.5 font-semibold rounded-xl px-5 py-2.5 text-sm disabled:opacity-40 focus:outline-none">Continue <ChevronRight className="w-4 h-4" /></button>
            : <button disabled={!canNext} onClick={() => run(form)} className="btn-em inline-flex items-center gap-1.5 font-semibold rounded-xl px-5 py-2.5 text-sm disabled:opacity-40 focus:outline-none"><Sparkles className="w-4 h-4" /> Show my matches</button>}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  SUBSIDY COPILOT — deterministic on-device parser (no external AI)  */
/* ================================================================== */
export function parseIntent(text) {
  const t = text.toLowerCase();
  const p = { ...BLANK, investment: 0 };
  const found = { chips: [] };
  const st = STATES.find((s) => t.includes(s.toLowerCase()));
  if (st) { p.state = st; p.district = "—"; found.chips.push(["📍", st]); }
  const amt = t.match(/(?:₹|rs\.?\s*)?(\d+(?:\.\d+)?)\s*(lakh|lac|l\b|crore|cr\b)/);
  if (amt) {
    const n = parseFloat(amt[1]); const mult = /cr/.test(amt[2]) ? 10000000 : 100000;
    p.investment = Math.round(n * mult); found.chips.push(["💰", inr(p.investment)]);
  }
  const sectorMap = [
    [/food|process|snack|masala|pickle|dairy|bakery/, "foodProcessing", "🏭 Food Processing"],
    [/solar|rooftop|renewable/, "solar", "☀️ Rooftop Solar"],
    [/farm|crop|agricult|kisan/, "farm", "🌾 Agriculture"],
    [/startup|tech|app|saas/, "startup", "🚀 Startup"],
    [/manufactur|factory|unit|msme|business|enterprise|shop/, "biz", "🏭 Enterprise"],
  ];
  let sector = null;
  for (const [re, key, chip] of sectorMap) if (re.test(t)) { sector = key; found.chips.push(["", chip]); break; }
  if (sector === "foodProcessing") { p.foodProcessing = "Yes"; p.userType = "Entrepreneur"; }
  else if (sector === "solar") { p.userType = "Household"; p.electricity = ""; }
  else if (sector === "farm") { p.userType = "Farmer"; }
  else if (sector === "startup") { p.userType = "Startup"; }
  else if (sector === "biz") { p.userType = "Entrepreneur"; }
  if (/student|scholar/.test(t)) p.userType = "Student";
  if (p.userType) found.chips.push(["👤", p.userType]);
  if (/loan|credit|finance/.test(t)) p.loan = "Yes";
  if (/new|start|set ?up|open/.test(t)) p.status = "New project";
  p.incomeMax = p.incomeMax || 2000000; p.incomeLabel = p.incomeLabel || "—";
  return { profile: p, found };
}
export const COPILOT_GAPS = [
  { k: "loan", q: "Bank loan planned?", when: (p) => p.loan === "" },
  { k: "status", q: "New project?", vals: ["New project", "Expansion of existing activity"], when: (p) => p.status === "" },
  { k: "landholding", q: "Family holds farmland?", when: (p) => p.userType === "Farmer" && p.landholding === "" },
  { k: "electricity", q: "Electricity connection in your name?", when: (p) => p.userType === "Household" && p.electricity === "" },
  { k: "dpiit", q: "DPIIT-recognised?", when: (p) => p.userType === "Startup" && p.dpiit === "" },
  { k: "incorpUnder2", q: "Incorporated within 2 years?", when: (p) => p.userType === "Startup" && p.incorpUnder2 === "" },
];
export function Copilot({ openScheme }) {
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState(null);
  const analyse = (t) => setParsed(parseIntent(t));
  const setP = (k, v) => setParsed((x) => ({ ...x, profile: { ...x.profile, [k]: v } }));
  const gaps = parsed ? COPILOT_GAPS.filter((g) => g.when(parsed.profile)) : [];
  const matches = parsed && gaps.length === 0
    ? SCHEMES.map((s) => ({ s, m: matchScheme(s, parsed.profile) })).filter((r) => r.m.pct != null && r.m.matched > 0).sort((a, b) => b.m.pct - a.m.pct).slice(0, 4)
    : null;
  const example = "I want to start a ₹20 lakh food-processing business in Gujarat.";
  return (
    <div className="fade-in space-y-6 max-w-3xl mx-auto">
      <div>
        <Eyebrow dark>Guided discovery — rule-based, on-device</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright flex items-center gap-3"><Bot className="w-7 h-7 tx-cy" /> Subsidy360 Copilot</h1>
        <p className="text-sm tx-dim mt-1">Tell me what you're trying to do. The Copilot reads your goal, builds a profile, and screens it against the verified official criteria — deterministically, with no generated eligibility claims.</p>
      </div>
      <div className="card-d p-6 space-y-4">
        <div className="flex gap-2">
          <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && text.trim() && analyse(text)}
            placeholder={`e.g., "${example}"`}
            className="flex-1 rounded-xl border bd-line px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 tx-bright" style={{ background: "var(--navy3)" }} />
          <button onClick={() => text.trim() && analyse(text)} className="btn-em rounded-xl px-4 font-semibold focus:outline-none" aria-label="Analyse"><Send className="w-4 h-4" /></button>
        </div>
        <button onClick={() => { setText(example); analyse(example); }} className="t11 tx-cy hover:underline f-mono">Try the demo prompt →</button>
        {parsed && (
          <div className="rise space-y-4">
            <div>
              <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-2">Profile understood</div>
              <div className="flex flex-wrap gap-2">
                {parsed.found.chips.map(([ic, label], i) => (
                  <span key={i} className="chip chip-src-d">{ic} {label}</span>
                ))}
                {parsed.found.chips.length === 0 && <span className="t11 tx-dim italic">Couldn't detect a state, amount or activity — try adding them.</span>}
              </div>
            </div>
            {gaps.length > 0 && (
              <div>
                <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-2">Quick confirmations</div>
                <div className="space-y-3">
                  {gaps.map((g) => (
                    <div key={g.k} className="flex items-center justify-between gap-3 flex-wrap">
                      <span className="text-sm tx-dim">{g.q}</span>
                      <div className="flex gap-2">
                        {(g.vals || ["Yes", "No"]).map((v) => (
                          <button key={v} onClick={() => setP(g.k, v)} className="btn-ghost-d t11 rounded-full px-3 py-1.5 font-medium focus:outline-none">{v}</button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {matches && (
              <div>
                <div className="f-mono t10 uppercase tracking-widest tx-gd mb-2">Top matches</div>
                <div className="space-y-2.5">
                  {matches.map(({ s, m }) => (
                    <div key={s.id} className="rounded-xl border bd-line p-4 bg-navy3">
                      <div className="flex items-center justify-between gap-3">
                        <div className="font-semibold tx-bright text-sm">{s.name.split("(")[0].trim()}</div>
                        <div className="f-mono text-xl font-bold tx-em shrink-0">{m.pct}%</div>
                      </div>
                      <div className="t11 tx-dim mt-1"><strong className="tx-bright">Why this matched:</strong> {m.parts.filter((x) => x.state === "pass").map((x) => x.text).join("; ") || "—"}{m.manual > 0 && ` · ${m.manual} criteria need manual verification`}</div>
                      <div className="flex items-center gap-3 mt-2 flex-wrap">
                        <span className="t10 f-mono tx-dim2">{s.source_org}</span>
                        <button onClick={() => openScheme(s.id)} className="t11 tx-cy hover:underline font-medium inline-flex items-center gap-1">Verify eligibility <ArrowRight className="w-3 h-3" /></button>
                      </div>
                    </div>
                  ))}
                  {matches.length === 0 && <div className="t11 tx-dim italic">No imported scheme's machine-checkable criteria match this profile — browse All Schemes for records pending full rule import.</div>}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      <MatchDisclaimer dark />
    </div>
  );
}

/* ================================================================== */
/*  WHAT-IF SIMULATOR                                                  */
/* ================================================================== */
export function WhatIf({ openScheme }) {
  const [inv, setInv] = useState(2000000);
  const [incomeIx, setIncomeIx] = useState(2);
  const [userType, setUserType] = useState("Entrepreneur");
  const [food, setFood] = useState("Yes");
  const [loan, setLoan] = useState("Yes");
  const prof = {
    ...BLANK, state: "Gujarat", district: "—", userType,
    incomeMax: INCOME_BANDS[incomeIx].max, incomeLabel: INCOME_BANDS[incomeIx].label,
    investment: inv, loan, status: "New project",
    landholding: userType === "Farmer" ? "Yes" : "", electricity: userType === "Household" ? "Yes" : "",
    dpiit: userType === "Startup" ? "Yes" : "", incorpUnder2: userType === "Startup" ? "Yes" : "",
    foodProcessing: ["MSME", "Entrepreneur", "Self-employed"].includes(userType) ? food : "",
  };
  const rows = SCHEMES.map((s) => ({ s, m: matchScheme(s, prof) })).filter((r) => r.m.pct != null);
  const passing = rows.filter((r) => r.m.pct === 100);
  const ranges = passing.map((r) => r.s.benefitCalc ? r.s.benefitCalc(inv) : (r.s.max_benefit != null ? [r.s.max_benefit] : null)).filter(Boolean);
  const lo = ranges.reduce((t, r) => t + r[0], 0);
  const hi = ranges.reduce((t, r) => t + (r[1] ?? r[0]), 0);
  const loAnim = useCountUp(lo, 500);
  return (
    <div className="fade-in space-y-6">
      <div>
        <Eyebrow dark>Scenario analysis — not a guaranteed benefit</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">What If?</h1>
        <p className="text-sm tx-dim mt-1">Explore how changing your economic situation changes your subsidy opportunities. Benefit figures apply the official benefit formulas of fully-matching verified schemes to your scenario — indicative only.</p>
      </div>
      <div className="grid lg:grid-cols-5 gap-4">
        <div className="card-d p-6 lg:col-span-2 space-y-5">
          <div>
            <div className="flex justify-between items-baseline mb-1">
              <span className="f-mono t10 uppercase tracking-widest tx-dim2">Investment</span>
              <span className="f-mono text-lg font-bold tx-gd">{inr(inv)}</span>
            </div>
            <input type="range" min={100000} max={10000000} step={100000} value={inv} onChange={(e) => setInv(Number(e.target.value))} className="w-full accent-emerald-400" />
            <div className="flex justify-between f-mono t9 tx-dim2"><span>₹1L</span><span>₹1 Cr</span></div>
          </div>
          <div>
            <div className="flex justify-between items-baseline mb-1">
              <span className="f-mono t10 uppercase tracking-widest tx-dim2">Annual income</span>
              <span className="f-mono text-sm font-bold tx-bright">{INCOME_BANDS[incomeIx].label}</span>
            </div>
            <input type="range" min={0} max={3} step={1} value={incomeIx} onChange={(e) => setIncomeIx(Number(e.target.value))} className="w-full accent-cyan-400" />
          </div>
          <div>
            <div className="f-mono t10 uppercase tracking-widest tx-dim2 mb-2">Applicant type</div>
            <div className="flex flex-wrap gap-2">
              {["Farmer", "Entrepreneur", "MSME", "Startup", "Household"].map((t) => (
                <button key={t} onClick={() => setUserType(t)} className={`t11 rounded-full px-3 py-1.5 font-medium border focus:outline-none ${userType === t ? "tx-em" : "btn-ghost-d"}`} style={userType === t ? { borderColor: "var(--em)", background: "rgba(24,185,129,.12)" } : {}}>{t}</button>
              ))}
            </div>
          </div>
          {["MSME", "Entrepreneur", "Self-employed"].includes(userType) && (
            <div className="flex items-center justify-between">
              <span className="text-sm tx-dim">Food-processing activity?</span>
              <div className="flex gap-2">{["Yes", "No"].map((v) => <button key={v} onClick={() => setFood(v)} className={`t11 rounded-full px-3 py-1.5 font-medium border focus:outline-none ${food === v ? "tx-em" : "btn-ghost-d"}`} style={food === v ? { borderColor: "var(--em)", background: "rgba(24,185,129,.12)" } : {}}>{v}</button>)}</div>
            </div>
          )}
          <div className="flex items-center justify-between">
            <span className="text-sm tx-dim">Bank loan in financing?</span>
            <div className="flex gap-2">{["Yes", "No"].map((v) => <button key={v} onClick={() => setLoan(v)} className={`t11 rounded-full px-3 py-1.5 font-medium border focus:outline-none ${loan === v ? "tx-em" : "btn-ghost-d"}`} style={loan === v ? { borderColor: "var(--em)", background: "rgba(24,185,129,.12)" } : {}}>{v}</button>)}</div>
          </div>
        </div>
        <div className="lg:col-span-3 space-y-4">
          <div className="card-d p-6 relative overflow-hidden">
            <div className="f-mono t10 uppercase tracking-widest tx-dim2">Your subsidy opportunity — scenario estimate</div>
            <div className="f-mono font-bold tx-gd mt-1" style={{ fontSize: "clamp(1.8rem,4vw,2.8rem)" }}>
              {ranges.length === 0 ? <span className="text-xl italic tx-dim">No fully-matching quantifiable scheme</span>
                : lo === hi ? inr(loAnim) : <>{inr(lo)} <span className="tx-dim2 text-xl">–</span> {inr(hi)}</>}
            </div>
            <div className="t11 tx-dim mt-1">
              Sum of official benefit formulas across <strong className="tx-bright">{passing.length}</strong> fully-matching scheme{passing.length === 1 ? "" : "s"} ·
              indicative scenario analysis, not a guaranteed or combinable amount (see combination rules).
            </div>
          </div>
          <div className="grid sm:grid-cols-3 gap-3">
            {[["Schemes evaluated", rows.length], ["Fully matching", passing.length], ["Needing manual checks", rows.reduce((t, r) => t + r.m.manual, 0)]].map(([l, v]) => (
              <div key={l} className="card-d p-4"><div className="f-mono text-2xl font-bold tx-cy">{v}</div><div className="t10 f-mono uppercase tracking-widest tx-dim2 mt-1">{l}</div></div>
            ))}
          </div>
          <div className="space-y-2.5">
            {rows.sort((a, b) => b.m.pct - a.m.pct).map(({ s, m }) => {
              const br = s.benefitCalc ? s.benefitCalc(inv) : null;
              return (
                <div key={s.id} className="card-l lift p-4 flex items-center justify-between gap-4 flex-wrap">
                  <div className="min-w-0">
                    <div className="font-semibold tx-ink text-sm">{s.name.split("(")[0].trim()}</div>
                    <div className="t11 tx-ink3">{m.matched}/{m.evaluable} criteria · {m.manual} manual{br && m.pct === 100 ? <> · scenario benefit <strong className="f-mono tx-emd">{br.length === 2 ? `${inr(br[0])}–${inr(br[1])}` : inr(br[0])}</strong></> : null}</div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className={`f-mono text-lg font-bold ${m.pct === 100 ? "tx-emd" : m.pct >= 50 ? "tx-cyd" : "tx-rd"}`}>{m.pct}%</span>
                    <button onClick={() => openScheme(s.id)} className="t11 tx-cyd hover:underline font-medium">Record →</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <MatchDisclaimer dark />
    </div>
  );
}

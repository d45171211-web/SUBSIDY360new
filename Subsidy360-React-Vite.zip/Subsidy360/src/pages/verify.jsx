import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  Legend, PieChart, Pie, Cell,
} from "recharts";
import {
  LayoutDashboard, Search, Compass, ListChecks, GitMerge, Landmark, Scale,
  BookOpen, Info, Menu, X, ChevronRight, ChevronLeft, CheckCircle2, AlertTriangle,
  XCircle, ArrowRight, ArrowDown, MapPin, Users, Wallet, TrendingUp, Layers, Sparkles,
  FileText, BadgeCheck, CircleDollarSign, PlayCircle, Filter, RotateCcw,
  ExternalLink, Database, ShieldCheck, CircleHelp, CalendarDays, Library,
  ScrollText, CircleSlash, FlaskConical, Bot, SlidersHorizontal, Radar, Grid3x3,
  Send,
} from "lucide-react";
import { SCHEMES, loadExternalSchemes } from "../data";
import { IMPORT_DATE, BUDGET_SRC } from "../data/financials";
import { SOURCES, COMBO_RULES, RADAR } from "../data/sources";
import { inr, cr, NR, matchScheme, dataConfidence, reVsBe, beOf, combineVerdict,
  SECTORS, BEN_TYPES, INCOME_BANDS, STATES, DEMO_PROFILE, BLANK } from "../engine";
import { Logo, Eyebrow, Chip, StatusChip, SourceInfo, Field, NRRow, ChartTip,
  CH, AXIS_D, GRID_D, Disclaimer, ImportBadge, MatchDisclaimer, SchemeCard } from "../components/shared";
import { useCountUp } from "../hooks";

/* ================================================================== */
/*  POLICY RADAR                                                       */
/* ================================================================== */
export function PolicyRadar() {
  const tagStyle = { NEW: "chip-ver-d", FUNDING: "chip-gd", UPDATED: "chip-src-d", DEADLINE: "chip-warn" };
  return (
    <div className="fade-in space-y-5 max-w-4xl mx-auto">
      <div>
        <Eyebrow dark>Verified recent changes</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright flex items-center gap-3"><Radar className="w-7 h-7 tx-cy" /> Policy Radar</h1>
        <p className="text-sm tx-dim mt-1">Government changes detected in the latest import — every card carries its department, date and official source. Only verified events are shown; there is no live feed in this build.</p>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {RADAR.map((r, i) => (
          <div key={i} className="card-d lift p-5">
            <div className="flex items-center justify-between gap-2 mb-2">
              <Chip kind={tagStyle[r.tag] || "chip-src-d"}>{r.tag}</Chip>
              <span className="f-mono t10 tx-dim2">{r.date}</span>
            </div>
            <div className="font-semibold tx-bright">{r.scheme}</div>
            <p className="t13 tx-dim leading-relaxed mt-1">{r.text}</p>
            <div className="flex items-center justify-between gap-2 mt-3 flex-wrap">
              <span className="t10 f-mono tx-dim2">{r.dept}</span>
              <a href={r.src} target="_blank" rel="noopener noreferrer" className="t11 tx-cy hover:underline inline-flex items-center gap-1 font-medium">{r.srcName} <ExternalLink className="w-3 h-3" /></a>
            </div>
          </div>
        ))}
      </div>
      <Disclaimer dark />
    </div>
  );
}

/* ================================================================== */
/*  DATA SOURCES + METHODOLOGY + ABOUT                                 */
/* ================================================================== */
export function DataSources() {
  const verified = SCHEMES.filter((s) => s.data_status === "verified").length;
  const withFin = SCHEMES.filter((s) => s.fin).length;
  return (
    <div className="fade-in space-y-6 max-w-4xl mx-auto">
      <div>
        <Eyebrow dark>Update center</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">Data Sources</h1>
        <p className="text-sm tx-dim mt-1">Government Scheme Data — prototype synchronization (verified research import), last imported {IMPORT_DATE}. No live API connection in this build; nothing is labelled "live".</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[["Schemes indexed", SCHEMES.length], ["Fully verified", verified], ["Financials verified", SCHEMES.length], ["Budget series attached", withFin]].map(([l, v]) => (
          <div key={l} className="card-d p-5"><div className="f-mono text-2xl font-bold tx-gd">{v}</div><div className="text-sm font-medium tx-dim mt-0.5">{l}</div></div>
        ))}
      </div>
      <div className="card-l p-6">
        <h3 className="font-semibold tx-ink mb-3 flex items-center gap-2"><Library className="w-4 h-4 tx-cyd" /> Source hierarchy in use</h3>
        <div className="space-y-3">
          {SOURCES.map((src) => (
            <div key={src.name} className="flex items-start gap-3 border-b bd-soft pb-3 last:border-0 last:pb-0">
              <span className={`f-mono t10 shrink-0 rounded-md px-2 py-1 border ${src.level <= 3 ? "chip-ver" : src.level === 4 ? "chip-src" : "chip-nr"}`}>L{src.level}</span>
              <div className="min-w-0">
                <a href={src.url} target="_blank" rel="noopener noreferrer" className="font-medium tx-ink hover:tx-cyd inline-flex items-center gap-1 text-sm">{src.name} <ExternalLink className="w-3 h-3" /></a>
                <p className="t11 tx-ink3">{src.role}</p>
              </div>
            </div>
          ))}
        </div>
        <p className="t11 tx-ink2 mt-4 bg-paper rounded-xl p-3 border bd-soft">
          Hierarchy: L1 official government API → L2 official dataset (data.gov.in) → L3 official webpage/document →
          L4 myScheme → L5 other (never authoritative for financial or eligibility claims). Connecting a live L1/L2
          feed replaces this import without changing the record format.
        </p>
      </div>
      <Disclaimer dark />
    </div>
  );
}
export function Methodology() {
  const items = [
    ["Primary sources", "Official Government of India and State Government sources only: scheme portals, certified guidelines, and Union Budget documents. myScheme and data.gov.in are the designated discovery and dataset layers for scaling the database."],
    ["Scheme discovery", "Records are structured to the myScheme information model (scheme, ministry, eligibility, benefits, application) so live myScheme data can replace the current import field-for-field."],
    ["Financial information", "All figures are scheme-wise Actuals, Budget Estimates or Revised Estimates from Union Budget documents. Estimate types are always labelled and never mixed. Scheme-level sanctioned/released/utilised figures are not published in these sources and are shown as Not reported — never derived from unrelated budget figures."],
    ["Data verification", "Every record stores its source organisation, source type, official URL and a last-verified date. The Data Confidence score measures completeness and freshness of the record, not the trustworthiness of the scheme."],
    ["Missing information", "Fields not confirmed from an official source are stored as null and rendered as Not reported. The application never estimates, extrapolates or fills gaps with generated values."],
    ["Eligibility", "The Subsidy360 Match tests only machine-checkable official criteria and flags the rest for manual verification. It is an informational ranking; Subsidy360 does not replace official government eligibility decisions."],
    ["Combination rules", "Compatibility verdicts require an explicit official rule on record, shown with source and verification date as evidence. Pairings without evidence return Compatibility not established rather than an inferred answer."],
    ["Scenario analysis", "The What-If simulator and Copilot apply official benefit formulas to hypothetical profiles. Outputs are labelled scenario estimates — indicative, not guaranteed, and never presented as official decisions."],
    ["Synchronization", "This build runs on a verified research import dated 24/08/2026 (prototype synchronization). It is not a live feed and is never labelled as one."],
  ];
  return (
    <div className="fade-in space-y-4 max-w-3xl mx-auto">
      <div>
        <Eyebrow dark>How the data is handled</Eyebrow>
        <h1 className="f-display text-2xl md:text-3xl font-bold tx-bright">Data Methodology</h1>
      </div>
      {items.map(([h, t]) => (
        <div key={h} className="card-l p-6">
          <h3 className="font-semibold tx-ink mb-1.5 flex items-center gap-2"><FlaskConical className="w-4 h-4 tx-cyd" /> {h}</h3>
          <p className="text-sm tx-ink2 leading-relaxed">{t}</p>
        </div>
      ))}
      <Disclaimer dark />
    </div>
  );
}
export function About() {
  const concepts = ["Information asymmetry", "Government expenditure", "Subsidies", "Incentives", "Public finance", "Resource allocation", "Utilisation efficiency"];
  return (
    <div className="fade-in space-y-6 max-w-3xl mx-auto">
      <div className="text-center py-6">
        <div className="flex justify-center mb-4"><Logo /></div>
        <p className="text-sm tx-dim max-w-xl mx-auto leading-relaxed">
          Subsidy360 is not another list of government schemes. It is an evidence-based interface that connects citizens
          with official government schemes while making public subsidy allocation and utilisation easier to understand.
        </p>
      </div>
      <div className="card-l p-6">
        <h3 className="font-semibold tx-ink mb-2">The problem</h3>
        <p className="text-sm tx-ink2 leading-relaxed">People struggle to discover government schemes, verify eligibility, and see how allocated public money is actually spent — and most tools respond with confident numbers of unknown origin.</p>
      </div>
      <div className="card-l p-6">
        <h3 className="font-semibold tx-ink mb-2">The approach</h3>
        <p className="text-sm tx-ink2 leading-relaxed">Every record cites an official source with a verification date; every financial figure is a labelled BE/RE/Actual from budget documents; missing data says "Not reported"; combination verdicts require official evidence. Accuracy and source transparency are the core features — not decoration on a dashboard.</p>
      </div>
      <div className="card-l p-6">
        <h3 className="font-semibold tx-ink mb-3">Economics connection</h3>
        <div className="flex flex-wrap gap-2">{concepts.map((c) => <span key={c} className="chip chip-src">{c}</span>)}</div>
      </div>
      <Disclaimer dark />
    </div>
  );
}

